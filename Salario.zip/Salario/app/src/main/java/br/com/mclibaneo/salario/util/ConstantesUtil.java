package br.com.mclibaneo.salario.util;

public class ConstantesUtil {
    private static String nomeUsuario;

    public static String getNomeUsuario() {
        return nomeUsuario;
    }

    public static void setNomeUsuario(String nomeUsuario) {
        ConstantesUtil.nomeUsuario = nomeUsuario;
    }
}
