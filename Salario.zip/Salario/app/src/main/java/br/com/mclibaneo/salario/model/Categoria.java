package br.com.mclibaneo.salario.model;


import java.io.Serializable;

public class Categoria implements Serializable {

    private Long idCategoria;
    private String nomeCategoria;
    private String categoriaPai;

    public Categoria(){}
    public Categoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }

    public Long getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Long idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNomeCategoria() {
        return nomeCategoria;
    }

    public void setNomeCategoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }

    public String getCategoriaPai() {
        return categoriaPai;
    }

    public void setCategoriaPai(String categoriaPai) {
        this.categoriaPai = categoriaPai;
    }

    @Override
    public String toString() {
        return nomeCategoria;
    }
}
