package br.com.mclibaneo.salario.contract;

import android.provider.BaseColumns;

public final class MovimentacaoContract {
    public MovimentacaoContract(){}

    public static abstract class cMovimentacao implements BaseColumns{
        public static final String TABLE_NAME_DESPESA = "despesa";
        public static final String TABLE_NAME_RECEITA = "receita";
        public static final String COLUMN_NAME_VALOR = "valor_movimentacao";
        public static final String COLUMN_NAME_DESCRICAO = "descricao_movimentacao";
        public static final String COLUMN_NAME_CATEGORIA = "categoria_movimentacao";
        public static final String COLUMN_NAME_DATA = "data_movimentacao";
        public static final String COLUMN_NAME_FIXA = "fixa_movimentacao";

        public static final String COMMA_SEP = ",";
        public static final String SEP = " ";

        public static final String SQL_CREATE_TABLE_DESPESA = "CREATE TABLE IF NOT EXISTS"+SEP+cMovimentacao.TABLE_NAME_DESPESA+"("+
                cMovimentacao._ID+SEP+"INTEGER UNIQUE PRIMARY KEY"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_VALOR+SEP+"REAL NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_DESCRICAO+SEP+"TEXT NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_CATEGORIA+SEP+"TEXT NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_DATA+SEP+"TEXT NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_FIXA+SEP+"INTEGER NOT NULL"+")";

        public static final String SQL_CREATE_TABLE_RECEITA = "CREATE TABLE IF NOT EXISTS"+SEP+cMovimentacao.TABLE_NAME_RECEITA+"("+
                cMovimentacao._ID+SEP+"INTEGER UNIQUE PRIMARY KEY"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_VALOR+SEP+"REAL NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_DESCRICAO+SEP+"TEXT NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_CATEGORIA+SEP+"TEXT NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_DATA+SEP+"TEXT NOT NULL"+COMMA_SEP+SEP+
                cMovimentacao.COLUMN_NAME_FIXA+SEP+"INTEGER NOT NULL"+")";

        public static final String SQL_DELETE_TABLE_DESPESA = "DROP TABLE IF EXISTS"+SEP+cMovimentacao.TABLE_NAME_DESPESA;
        public static final String SQL_DELETE_TABLE_RECEITA = "DROP TABLE IF EXISTS"+SEP+cMovimentacao.TABLE_NAME_RECEITA;

    }
}
