package br.com.mclibaneo.salario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import br.com.mclibaneo.salario.helper.CategoriaHelper;
import br.com.mclibaneo.salario.helper.CategoriasHelper;
import br.com.mclibaneo.salario.model.Categoria;

public class CategoriaActivity extends MenuActivity {
    private CategoriaHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categoria);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        helper = new CategoriaHelper(CategoriaActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        helper.verificaExtra();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_categoria, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_categoria_lista) {
            startActivity(new Intent(this, CategoriasActivity.class));
            return true;
        }

        if(id == R.id.menu_categoria_config){
            startActivity(new Intent(this, UsuarioActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
