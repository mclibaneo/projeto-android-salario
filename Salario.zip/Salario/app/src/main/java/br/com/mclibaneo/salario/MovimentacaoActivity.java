package br.com.mclibaneo.salario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import br.com.mclibaneo.salario.helper.MovimentacaoHelper;

public class MovimentacaoActivity extends MenuActivity {
    private MovimentacaoHelper helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movimentacao);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        helper = new MovimentacaoHelper(MovimentacaoActivity.this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        helper.recuperaIntentExtras();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_movimentacao, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        int id = item.getItemId();

        if (id == R.id.menu_movimentacao_lista_despesas) {
            intent = new Intent(this, MovimentacoesActivity.class);
            intent.putExtra(this.getString(R.string.intencaoDespesa), true);
            startActivity(intent);
            this.finish();
            return true;
        }

        if(id == R.id.menu_movimentacao_lista_receitas){
            intent = new Intent(this, MovimentacoesActivity.class);
            intent.putExtra(this.getString(R.string.intencaoDespesa), false);
            startActivity(intent);
            this.finish();
            return true;
        }

        if(id == R.id.menu_main_salario){
            startActivity(new Intent(this, MainActivity.class));
            this.finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
