package br.com.mclibaneo.salario.contract;

import android.provider.BaseColumns;

public final class UsuarioCarteiraContract {
    public UsuarioCarteiraContract(){}

    public static abstract class cUsuarioCarteira implements BaseColumns{
        public static final String TABLE_NAME = "usuario_carteira";
        public static final String COLUMN_NAME_USUARIO = "nome_usuario";
        public static final String COLUMN_NAME_EMAIL = "email_usuario";
        public static final String COLUMN_NAME_SALARIO_BRUTO = "salario_bruto";
        public static final String COLUMN_NAME_POUPANCA = "poupanca";

        public static final String COMMA_SEP = ",";
        public static final String SEP = " ";

        public static final String SQL_CREATE_TABLE_USUARIO_CARTEIRA =
                "CREATE TABLE"+SEP+cUsuarioCarteira.TABLE_NAME+"("+
                        cUsuarioCarteira._ID+SEP+"INTEGER UNIQUE PRIMARY KEY"+COMMA_SEP+
                        cUsuarioCarteira.COLUMN_NAME_USUARIO+SEP+"TEXT UNIQUE NOT NULL"+COMMA_SEP+
                        cUsuarioCarteira.COLUMN_NAME_EMAIL+SEP+"TEXT UNIQUE NOT NULL"+COMMA_SEP+
                        cUsuarioCarteira.COLUMN_NAME_SALARIO_BRUTO+SEP+"REAL UNIQUE NOT NULL"+COMMA_SEP+
                        cUsuarioCarteira.COLUMN_NAME_POUPANCA+SEP+"REAL UNIQUE"+")";

        public static final String SQL_DELETE_TABLE_USUARIO_CARTEIRA =
                "DROP TABLE IF EXISTS"+SEP+cUsuarioCarteira.TABLE_NAME;
    }
}
