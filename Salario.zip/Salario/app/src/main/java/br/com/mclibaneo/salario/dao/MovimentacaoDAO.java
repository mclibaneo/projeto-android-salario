package br.com.mclibaneo.salario.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.contract.MovimentacaoContract;
import br.com.mclibaneo.salario.model.Movimentacao;
import br.com.mclibaneo.salario.util.DataUtil;

public class MovimentacaoDAO {
    private Context context;
    //necessario para obter uma instancia do banco de dados
    private final DataBaseHelper dbHelper;
    //necessario para executar instrucoes sql
    private SQLiteDatabase db;
    /*
    * construtor padrao contextualizado
    * instancia a variavel de acesso unico ao banco de dados
    * */
    public MovimentacaoDAO(Context context){
        this.context = context;
        this.dbHelper = DataBaseHelper.getInstance(context);
    }
    /*
    * param movimentcao; retorno: ContentValues
    * monta um objeo do tipo movimentacao para ser inserido no banco de dados
    * */
    private ContentValues toValues(Movimentacao movimentacao){
        ContentValues cv = new ContentValues();
        cv.put(MovimentacaoContract.cMovimentacao._ID, movimentacao.getIdMovimentacao());
        cv.put(MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR, movimentacao.getValorMovimentacao());
        cv.put(MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO, movimentacao.getDescricaoMovimentacao());
        cv.put(MovimentacaoContract.cMovimentacao.COLUMN_NAME_CATEGORIA, movimentacao.getCategoriaMovimentacao());
        cv.put(MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA, movimentacao.getDataMovimentacaoString());
        cv.put(MovimentacaoContract.cMovimentacao.COLUMN_NAME_FIXA, movimentacao.getEfixa());
        return cv;
    }
    /*
    * param: movimentacao, boolean; retorno: long
    * verifica se eh um despesa ou receita
    * e realiza operacao de salvar ou editar no banco de dados,
    * */
    public long salvar(Movimentacao movimentacao, boolean intencaoDespesa){
        long count = 0;
        String tabela = MovimentacaoContract.cMovimentacao.TABLE_NAME_DESPESA;
        ContentValues values = toValues(movimentacao);
        db = dbHelper.getWritableDatabase();
        // se a intencao nao for despesa
        if(!intencaoDespesa)
            tabela = MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA;
        if(movimentacao.getIdMovimentacao() != null){
            String whereClause = MovimentacaoContract.cMovimentacao._ID +"=?";
            String[] whereArgs = new String[]{String.valueOf(movimentacao.getIdMovimentacao())};
            count = db.update(
                    tabela,// tabela
                    values, // valores a serem alterados
                    whereClause, // clausula WHERE
                    whereArgs // valores da clausula WHERE
            );
            Log.i(context.getString(R.string.log_editou), ""+movimentacao.getIdMovimentacao()+"");
        }else{
            count = db.insert(
                    tabela,
                    null,
                    values
            );
        }
        Log.i(context.getString(R.string.log_inseriu), movimentacao.toString());
        return count;
    }
    /*
    * param: boolean; retorno: Cursor
    * retorna um cursor com as despesas ou receitas a depender do parametro
    * */
    private Cursor cursorListar(boolean intencaoDespesa, boolean total, boolean fixa, boolean mesPassado){
        Cursor cursor;
        String table = MovimentacaoContract.cMovimentacao.TABLE_NAME_DESPESA;
        if(!intencaoDespesa)
            table = MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA;
        String[] columns = {
                MovimentacaoContract.cMovimentacao._ID,
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR,
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO,
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_CATEGORIA,
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA,
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_FIXA,
        };
        String dataInicio = DataUtil.getDataInicioMes();
        String dataFim = DataUtil.getDataFimMes();
        if(mesPassado){
            dataInicio = DataUtil.getDataInicioMesPassado();
            dataFim = DataUtil.getDataFimMesPassado();
        }
        String selection = null;
        String[] selectionArgs = null;
        if(!total){
            selection = MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA+
                    " BETWEEN date('"+dataInicio+"') AND date('"+dataFim+"')";

        }
        if(fixa){selection += " AND "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_FIXA+"=1";}
        db = dbHelper.getReadableDatabase();
        cursor = db.query(
                table,// nome da tabela --> String table
                columns,// colunas --> String[] columns
                selection,// clausula WHERE --> String selection
                selectionArgs,// argumentos da clausula WHERE --> String[] selectionArgs
                null,// agrupamento --> String groupBy
                null,// contendo --> String having
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA,// ordenacao --> String orderBy
                null // limite --> String limit
        );
        Log.i("SQL Listar", cursor.toString());
        return cursor;
    }
    /*
    * param: boolean intencaoDespesa, total, movFixa; retorno: List<Movimentacoes>
    * cria uma lista de movimentacoes despesa/receita a partir de um cursor
    * */
    public ArrayList<Movimentacao> listar(boolean intencaoDespesa, boolean total, boolean fixa, boolean mesPassado){
        ArrayList<Movimentacao> movimentacoes = new ArrayList<Movimentacao>();
        Cursor cursor = cursorListar(intencaoDespesa, total, fixa, mesPassado);
        while(cursor.moveToNext()){
            Movimentacao obj = new Movimentacao();
            obj.setIdMovimentacao(cursor.getLong(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao._ID)));
            obj.setValorMovimentacao(cursor.getDouble(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR)));
            obj.setDescricaoMovimentacao(cursor.getString(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO)));
            obj.setCategoriaMovimentacao(cursor.getString(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_CATEGORIA)));
            obj.setDataMovimentacaoString(cursor.getString(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA)));
            obj.setEfixa(cursor.getInt(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_FIXA)));
            movimentacoes.add(obj);
        }
        return movimentacoes;
    }
    /*
    * param: nenhum; retorno: movimentacao
    * */
    public Movimentacao retornaMovimentacaoSalarioBrutoBanco(){
        Movimentacao salarioBruto = null;
        db = dbHelper.getReadableDatabase();
        String sqlQuery = "SELECT * FROM "+MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA+
                " WHERE "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO+
                " LIKE '"+context.getString(R.string.salario_bruto)+"'"+
                " AND "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA+
                " BETWEEN date('"+DataUtil.getDataInicioMes()+"') AND date('"+DataUtil.getDataFimMes()+"')"+
                " LIMIT 1";
        Log.i("SELECT", sqlQuery);
        Cursor cursor = db.rawQuery(sqlQuery, null);
        if(cursor.getCount()>0){
            cursor.moveToFirst();
            salarioBruto = new Movimentacao();
            salarioBruto.setIdMovimentacao(cursor.getLong(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao._ID)));
            salarioBruto.setValorMovimentacao(cursor.getDouble(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR)));
            salarioBruto.setDescricaoMovimentacao(cursor.getString(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO)));
            salarioBruto.setCategoriaMovimentacao(cursor.getString(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_CATEGORIA)));
            salarioBruto.setDataMovimentacaoString(cursor.getString(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA)));
            salarioBruto.setEfixa(cursor.getInt(cursor.getColumnIndexOrThrow(MovimentacaoContract.cMovimentacao.COLUMN_NAME_FIXA)));
        }
        return salarioBruto;
    }
    /*
    * param: double -> valorSalarioBruto; retorno: void
    * atualiza o valor da receita 'salario bruto' do mes
    * */
    public void atualizaValorSalarioBrutoBanco(double valorSalarioBruto){
        int count = 0;
        db = dbHelper.getWritableDatabase();
        /*String sqlQuery = "UPDATE "+MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA+
                " SET "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR+"="+valorSalarioBruto+
                " WHERE "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO+
                " LIKE '"+context.getString(R.string.salario_bruto)+"'"+
                " AND "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA+
                " BETWEEN date('"+DataUtil.getDataInicioMes()+"') AND date('"+DataUtil.getDataFimMes()+"')";
        Log.i("UPDATE", sqlQuery);
        db.rawQuery(sqlQuery, null);*/
        String table = MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA;
        ContentValues values = new ContentValues();
        values.put(MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR, valorSalarioBruto);
        String whereClause = MovimentacaoContract.cMovimentacao.COLUMN_NAME_DESCRICAO+" LIKE '"+
                context.getString(R.string.salario_bruto)+"'" +
                " AND "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA+
                " BETWEEN date('"+DataUtil.getDataInicioMes()+"') AND date('"+DataUtil.getDataFimMes()+"')";
        count = db.update(table, values, whereClause, null);
        Log.i("UPDATE", ""+count);
    }
    /*
    * param: boolean; retorno: double
    * retorna a soma dos valores das despesas/receitas
    * */
    public Double getSomaValoresMovimentacoes(boolean intencaoDespesa, boolean total){
        double valor = 0;
        String table = intencaoDespesa ? MovimentacaoContract.cMovimentacao.TABLE_NAME_DESPESA : MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA;
        String selectSumValor = "SELECT SUM("+
                MovimentacaoContract.cMovimentacao.COLUMN_NAME_VALOR+")"+
                " AS soma FROM " + table;
        if(!total)
            selectSumValor += " WHERE "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA+
                    " BETWEEN date('"+ DataUtil.getDataInicioMes()+ "') AND date('"+ DataUtil.getDataFimMes()+"')";
        selectSumValor += " ORDER BY "+MovimentacaoContract.cMovimentacao.COLUMN_NAME_DATA;
        db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectSumValor, null);
        if(cursor!=null){
            cursor.moveToFirst();
            valor = cursor.getDouble(cursor.getColumnIndexOrThrow("soma"));
        }
        Log.i("SQL",selectSumValor);
        return valor;
    }
    /*
    * param: movimentacao, retorno: long
    * remove a movimentacao do banco de dados
    * */
    public long remover(Movimentacao movimentacao, boolean intencaoDespesa){
        long count = 0;
        db = dbHelper.getWritableDatabase();
        String table = intencaoDespesa ? MovimentacaoContract.cMovimentacao.TABLE_NAME_DESPESA :
                MovimentacaoContract.cMovimentacao.TABLE_NAME_RECEITA;
        String whereClause = MovimentacaoContract.cMovimentacao._ID+"=?";
        String[] whereArgs = {String.valueOf(movimentacao.getIdMovimentacao())};
        count = db.delete(
                table, //nome da tabela
                whereClause, //clausula WHERE
                whereArgs //argumentos da clausula WHERE
        );
        return count;
    }
    /**
     * param: nenhum; retorno: void
     * fecha conexao com banco de dados
     */
    public void close(){
        dbHelper.close();
    }
}
