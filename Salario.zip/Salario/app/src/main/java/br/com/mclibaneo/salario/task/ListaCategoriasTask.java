package br.com.mclibaneo.salario.task;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;

import java.util.ArrayList;

import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.model.Categoria;

public class ListaCategoriasTask extends AsyncTask<Object, Object, ArrayList<Categoria>> {
    private ProgressDialog progress;
    private Activity activityContext;
    private CategoriaDAO categoriaDAO;
    /*
    * contrutor
    * cria um construtor contextualizado
    * */
    public ListaCategoriasTask(Activity activityContext){
        this.activityContext = activityContext;
    }
    /*
    * onPreExecute
    * param: nenhum, retorno: void
    * prepara a janela que sera exibida na task
    * */
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progress = ProgressDialog.show(
                activityContext, // contetxo a ser mostrado na janela de progresso
                "Aguarde...", // titulo da janela de progresso
                "Carregando Informação", // mensagem da janela de progresso
                true, // indeterminado
                true); // pode ser cancelado
    }
    /*
    * doInBackground
    * param: Objects, retorno: ArrayLista<Categoria>
    * acao que sera excutada com a task for iniciada
    * */
    @Override
    protected ArrayList<Categoria> doInBackground(Object... params) {
        this.categoriaDAO = new CategoriaDAO(activityContext);
        ArrayList<Categoria> categorias = categoriaDAO.listar();
        return categorias;
    }
    /*
    * onProgressUpdate
    * param: Objects, retorno: void
    * mostra a janela no momento que a acao eh executada pela task
    * */
    @Override
    protected void onProgressUpdate(Object... values) {
        super.onProgressUpdate(values);
        progress = ProgressDialog.show(
                activityContext, // contetxo a ser mostrado na janela de progresso
                "Aguarde...", // titulo da janela de progresso
                "Carregando Informação", // mensagem da janela de progresso
                true, // indeterminado
                true); // pode ser cancelado
    }
    /*
    * onPostExecute
    * param: ArrayList<Categoria>, retorno: void
    * finaliza a task e todos os elementos criados, como exemplo, a janela de progresso
    * */
    @Override
    protected void onPostExecute(ArrayList<Categoria> categorias) {
        super.onPostExecute(categorias);
        progress.dismiss();
    }
}
