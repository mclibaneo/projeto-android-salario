package br.com.mclibaneo.salario.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import br.com.mclibaneo.salario.contract.CategoriaContract;
import br.com.mclibaneo.salario.model.Categoria;


/**
 * Created by 121101 on 19/04/2016.
 */
public class CategoriaDAO {
    private final DataBaseHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;

    public CategoriaDAO(Context context){
        this.context = context;
        this.dbHelper = DataBaseHelper.getInstance(context);
    }
    private ContentValues toValues(Categoria categoria){
        ContentValues cv = new ContentValues();
        cv.put("nome_categoria", categoria.getNomeCategoria());
        cv.put("nome_categoria_pai", categoria.getCategoriaPai());
        return  cv;
    }
    public void close(){
        dbHelper.close();
    }
    public long salvar(Categoria categoria){
        long newRowId;
        ContentValues values = toValues(categoria);
        db = dbHelper.getWritableDatabase();
        newRowId = db.insert(CategoriaContract.cCategoria.TABLE_NAME, CategoriaContract.cCategoria.COLUMN_NAME_PAI, values);
        return newRowId;
    }
    public ArrayList<Categoria> lista(){
        db = dbHelper.getReadableDatabase();
        String[] projection = {
                CategoriaContract.cCategoria._ID,
                CategoriaContract.cCategoria.COLUMN_NAME_NAME,
                CategoriaContract.cCategoria.COLUMN_NAME_PAI
        };
        Cursor c = db.query(
               CategoriaContract.cCategoria.TABLE_NAME, //nome da tabela --> String
                projection, // colunas da tabela --> String[]
                null, // colunas para clausula WHERE --> String[]
                null, // valores para clausula WHERE --> String[]
                CategoriaContract.cCategoria.COLUMN_NAME_PAI, // agrupar as linhas --> String
                null, // filtrar as linhas --> String
                null // ordernacao --> String
        );
        ArrayList<Categoria> categorias = new ArrayList<Categoria>();
        while(c.moveToNext()){
            Categoria categoria = new Categoria();
            categoria.setIdCategoria(c.getLong(c.getColumnIndexOrThrow(CategoriaContract.cCategoria._ID)));
            categoria.setNomeCategoria(c.getString(c.getColumnIndexOrThrow(CategoriaContract.cCategoria.COLUMN_NAME_NAME)));
            categoria.setCategoriaPai(c.getString(c.getColumnIndexOrThrow(CategoriaContract.cCategoria.COLUMN_NAME_PAI)));
           categorias.add(categoria);
        }
        return  categorias;
    }
    public void apagar(Categoria categoria){
        db = dbHelper.getWritableDatabase();
        String selection = CategoriaContract.cCategoria._ID+" = ?";
        String[] selectionArgs = {String.valueOf(categoria.getIdCategoria())};
        db.delete(CategoriaContract.cCategoria.TABLE_NAME, selection, selectionArgs);
    }
}
