package br.com.mclibaneo.salario.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

import br.com.mclibaneo.salario.contract.CategoriaContract;
import br.com.mclibaneo.salario.model.Categoria;

public class CategoriaDAO {
    private final DataBaseHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;
    /*
    * construtor
    * cria um construtor contextualizado e com o objeto de acesso ao banco de dados
    * */
    public CategoriaDAO(Context context){
        this.context = context;
        this.dbHelper = DataBaseHelper.getInstance(context);
    }
    /*
    * param: categoria, retorno: ContentValues
    * Cria um objeto do tipo content value informando pares chave/valor de um objeto categoria
    * */
    private ContentValues toValues(Categoria categoria){
        ContentValues cv = new ContentValues();
        cv.put(CategoriaContract.cCategoria.COLUMN_NAME_CATEGORIA, categoria.getNomeCategoria());
        cv.put(CategoriaContract.cCategoria.COLUMN_NAME_PAI, categoria.getCategoriaPai());
        return  cv;
    }
    public void close(){
        dbHelper.close();
    }
    /*
    * param: categoria, retorno: long
    * Insere ou atualiza a categoria no db se o ID da categoria nao for nulo,
    * retorna ID da linha inserida
    * */
    public long salvar(Categoria categoria){
        long count = 0;
        try {
            ContentValues values = toValues(categoria);
            db = dbHelper.getWritableDatabase();
            if(categoria.getIdCategoria()!=null){
                String selection = CategoriaContract.cCategoria._ID+"=?";
                String[] selectionArgs = {String.valueOf(categoria.getIdCategoria())};
                count = db.update(
                        CategoriaContract.cCategoria.TABLE_NAME, //nome da tabela
                        values, //novos valores
                        selection, //coluna a ser alterada
                        selectionArgs //valor da coluna a ser alterada
                );
                Log.i("Salvar:", "Atualiza "+count);
            }else{
                count = db.insert(
                        CategoriaContract.cCategoria.TABLE_NAME,// o nome da tabela no banco
                        CategoriaContract.cCategoria.COLUMN_NAME_PAI, // uma coluna cujo valor pode ser nulo
                        values); // todos os valores a serem inseridos definidos no ContentValues
                Log.i("Salvar:", "Novo "+count);
            }
        }catch (Exception e){
              new RuntimeException(e);
        }
        return count;
    }
    /*
    * param: nenhum, retorno: ArrayList<String>
    * retorna todas as categorias pais em ordem alfabetica
    * */
    public ArrayList<String> listarCategoriasPais(){
        ArrayList<Categoria> listaCategorias = listar();
        HashSet<String> hashPais = new HashSet<>();
        ArrayList<String> listaCategoriasPais = new ArrayList<>();
        for(Categoria categoria : listaCategorias){
            hashPais.add(categoria.getCategoriaPai());
        }
        for(String s : hashPais){
            listaCategoriasPais.add(s);
        }
        Collections.sort(listaCategoriasPais);
        return listaCategoriasPais;
    }
    /*
    * param: nenhum, retorno: ArrayList<Categoria>
    * retorna todas as categorias do banco de dados
    * */
    public ArrayList<Categoria> listar(){
        db = dbHelper.getReadableDatabase();
        String[] projection = {
                CategoriaContract.cCategoria._ID,
                CategoriaContract.cCategoria.COLUMN_NAME_CATEGORIA,
                CategoriaContract.cCategoria.COLUMN_NAME_PAI
        };
        Cursor c = db.query(
                CategoriaContract.cCategoria.TABLE_NAME, //nome da tabela --> String
                projection, // colunas da tabela --> String[]
                null, // colunas para clausula WHERE --> String[]
                null, // valores para clausula WHERE --> String[]
                null, // agrupar as linhas --> String
                null, // filtrar as linhas --> String
                CategoriaContract.cCategoria.COLUMN_NAME_PAI // ordernacao --> String
        );
        ArrayList<Categoria> categorias = new ArrayList<Categoria>();
        while(c.moveToNext()){
            Categoria categoria = new Categoria();
            categoria.setIdCategoria(c.getLong(c.getColumnIndexOrThrow(CategoriaContract.cCategoria._ID)));
            categoria.setNomeCategoria(c.getString(c.getColumnIndexOrThrow(CategoriaContract.cCategoria.COLUMN_NAME_CATEGORIA)));
            categoria.setCategoriaPai(c.getString(c.getColumnIndexOrThrow(CategoriaContract.cCategoria.COLUMN_NAME_PAI)));
            categorias.add(categoria);
        }
        return  categorias;
    }
    /*
    * param: nenhum, retorno: List<String>
    * retorna uma lista de string com as categorias
    * */
    public ArrayList<String> listarString(){
        ArrayList<String> lista = new ArrayList<String>();
        for(Categoria c : listar()){
            lista.add(c.getNomeCategoria());
        }
        return lista;
    }
    /*
    * param: nenhum, retorno: Cursor
    * retorna um cursor com todos os valores de categorias do banco de dados
    * */
    public Cursor cursorListaCategorias(){
        db = dbHelper.getReadableDatabase();
        String[] projection = {
                CategoriaContract.cCategoria._ID,
                CategoriaContract.cCategoria.COLUMN_NAME_CATEGORIA,
                CategoriaContract.cCategoria.COLUMN_NAME_PAI
        };
        Cursor cursor = db.query(
                CategoriaContract.cCategoria.TABLE_NAME, //nome da tabela --> String
                projection, // colunas da tabela --> String[]
                null, // colunas para clausula WHERE --> String[]
                null, // valores para clausula WHERE --> String[]
                CategoriaContract.cCategoria.COLUMN_NAME_PAI, // agrupar as linhas --> String
                null, // filtrar as linhas --> String
                CategoriaContract.cCategoria.COLUMN_NAME_PAI // ordernacao --> String
        );

        return  cursor;
    }
    /*
    * param: categoria, retorno: void
    * remove uma categoria do banco de dados
    * */
    public void remover(Categoria categoria){
        db = dbHelper.getWritableDatabase();
        String selection = CategoriaContract.cCategoria._ID+" = ?";
        String[] selectionArgs = {String.valueOf(categoria.getIdCategoria())};
        db.delete(CategoriaContract.cCategoria.TABLE_NAME, selection, selectionArgs);
    }
}
