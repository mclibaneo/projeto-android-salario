package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;
import java.util.Arrays;

import br.com.mclibaneo.salario.MovimentacoesActivity;
import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.dao.MovimentacaoDAO;
import br.com.mclibaneo.salario.model.Movimentacao;
import br.com.mclibaneo.salario.util.DataUtil;
import br.com.mclibaneo.salario.util.FormularioUtil;

public class MovimentacaoHelper extends Activity {

    private Activity movimentacaoActivity;

    private EditText et_movimentacao_valor;
    private EditText et_movimentacao_descricao;

    private TextView tv_movimentacao_ano;
    private TextView tv_movimentacao_id;

    private Spinner sp_movimentacao_categorias;
    private Spinner sp_movimentacao_dia;
    private Spinner sp_movimentacao_mes;

    private CheckBox cb_movimentacao_fixa;

    private Button bt_movimentacao_salvar;

    private String movID;
    private String movValor;
    private String movDescricao;
    private String movCategorias;
    private String movDia;
    private String movMes;
    private String movAno;

    private int movFixa = 0;

    private boolean intencaoDespesa;

    private MovimentacaoDAO movimentacaoDAO;
    private Movimentacao movimentacao;

    /*
    * construtor padrao
    * */
    public MovimentacaoHelper(Activity activity){
        this.movimentacaoActivity = activity;
        this.movimentacaoDAO = new MovimentacaoDAO(activity);
        this.movimentacao = new Movimentacao();

        recuperaInformacoesTela();
        //verifica intencoes
        recuperaIntentExtras();
        setListeners();

    }
    /*
    * param: nenhum, retorno: void
    * recupera as views da tela
    * */
    private void recuperaInformacoesTela(){
        this.et_movimentacao_valor = (EditText) movimentacaoActivity.findViewById(R.id.et_movimentacao_valor);
        this.et_movimentacao_descricao = (EditText) movimentacaoActivity.findViewById(R.id.et_movimentacao_descricao);
        this.sp_movimentacao_categorias = (Spinner) movimentacaoActivity.findViewById(R.id.sp_movimentacao_categoria);
        this.sp_movimentacao_dia = (Spinner) movimentacaoActivity.findViewById(R.id.sp_movimentacao_dia);
        this.sp_movimentacao_mes = (Spinner) movimentacaoActivity.findViewById(R.id.sp_movimentacao_mes);
        this.tv_movimentacao_ano = (TextView) movimentacaoActivity.findViewById(R.id.tv_movimentacao_ano);
        this.tv_movimentacao_id = (TextView) movimentacaoActivity.findViewById(R.id.tv_movimentacao_id);
        this.cb_movimentacao_fixa = (CheckBox) movimentacaoActivity.findViewById(R.id.cb_movimentacao_fixa);
        this.bt_movimentacao_salvar = (Button) movimentacaoActivity.findViewById(R.id.bt_movimentacao_salvar);
    }
    /*
    * param: nenhum, retorno: void
    * recupera as intents e extras caso existam
    * */
    public void recuperaIntentExtras(){
        this.intencaoDespesa = movimentacaoActivity.getIntent().getBooleanExtra(movimentacaoActivity.getString(R.string.intencaoDespesa), true);
        insereInformacoesTela();
        if(movimentacaoActivity.getIntent().hasExtra(movimentacaoActivity.getString(R.string.movimentacao))) {
            movimentacao = (Movimentacao) movimentacaoActivity.getIntent().
                    getSerializableExtra(movimentacaoActivity.getString(R.string.movimentacao));

            insereObjetoEdicao();
        }
    }
    /*
    * param: nenhum, retorno: void
    * insere os valores das cateorias e o dia e mes atual na tela
    * */
    public void insereInformacoesTela(){
        //cria spinner de dias
        FormularioUtil.criaSpinnerDias(sp_movimentacao_dia, movimentacaoActivity);
        //Insere o dia atual
        FormularioUtil.recuperaValorSpinner(sp_movimentacao_dia, String.valueOf(DataUtil.getDiaDoMes()));
        //cria spinner de meses
        FormularioUtil.criaSpinnerMeses(sp_movimentacao_mes, movimentacaoActivity);
        //insere o mes atual
        FormularioUtil.recuperaValorSpinner(sp_movimentacao_mes, String.valueOf(DataUtil.getMesExtenso()));
        //insere o ano atual
        tv_movimentacao_ano.setText(""+ String.valueOf(DataUtil.getAno()));
        //cria spinner categorias
        ArrayList<String> categorias = new CategoriaDAO(movimentacaoActivity).listarString();
        FormularioUtil.retornaSpinnerPopulado(sp_movimentacao_categorias, movimentacaoActivity, categorias);
        //altera texto do botao salvar
        if(intencaoDespesa){
            //mostra o spinner de categorias quando for uma despesa
            sp_movimentacao_categorias.setVisibility(View.VISIBLE);
            movimentacaoActivity.findViewById(R.id.tv_movimentacao_categoria).setVisibility(View.VISIBLE);
            bt_movimentacao_salvar.setText("Salvar Despesa");
        }else{
            //nao mostra o spinner de categorias quando for uma receita
            sp_movimentacao_categorias.setVisibility(View.GONE);
            movimentacaoActivity.findViewById(R.id.tv_movimentacao_categoria).setVisibility(View.GONE);
            bt_movimentacao_salvar.setText("Salvar Receita");
        }
    }
    /*
    * param: nenhum, retorno: void
    * recupera valores dos campos das views e insere nas variaveis
    * */
    private void recuperaValorVariaveis(){
        this.movID = tv_movimentacao_id.getText().toString().trim();
        this.movValor = et_movimentacao_valor.getText().toString().trim();
        this.movDescricao = et_movimentacao_descricao.getText().toString().trim();
        if(cb_movimentacao_fixa.isChecked())
            movFixa = 1;
        this.movAno = tv_movimentacao_ano.getText().toString().trim();
        //dia e mes sao buscados nos listeners
        //se intencao for receita categoria eh inserida manualmente como Receita
        if(!intencaoDespesa)
            movCategorias = "Receita";
    }
    /*
    * param: nenhum, retorno: boolean
    * monta objeto para ser salvo no banco,
    * mas antes verifica se os campos estao ok
    * */
    private boolean montaObjeto(){
        boolean retorno = true;
        recuperaInformacoesTela();
        recuperaValorVariaveis();
        if(!FormularioUtil.verificaCampos(Arrays.asList(movValor, movDescricao))) {
            retorno = false;
        }else{
            if(movimentacao.getIdMovimentacao()!=null)
                movimentacao.setIdMovimentacao(Long.parseLong(movID));
            if(!intencaoDespesa)
                movimentacao.setCategoriaMovimentacao("Receita");
            else
                movimentacao.setCategoriaMovimentacao(movCategorias);
            movimentacao.setDescricaoMovimentacao(movDescricao);
            movimentacao.setEfixa(movFixa);
            movimentacao.setValorMovimentacao(Double.parseDouble(movValor));
            movimentacao.setDataMovimentacaoString(DataUtil.criaDataBanco(movAno, movMes, movDia));
        }
        return retorno;
    }
    /*
    * param: movimentacao, retorno: void
    * monta objeto na tela para edicao
    * */
    private void insereObjetoEdicao(){
        tv_movimentacao_id.setText(String.valueOf(movimentacao.getIdMovimentacao()));
        et_movimentacao_valor.setText(String.valueOf(movimentacao.getValorMovimentacao()));
        et_movimentacao_descricao.setText(movimentacao.getDescricaoMovimentacao());
        FormularioUtil.recuperaValorSpinner(sp_movimentacao_categorias, movimentacao.getCategoriaMovimentacao());
        //insere o dia no spinner
        FormularioUtil.recuperaValorSpinner(sp_movimentacao_dia,
                DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 1));
        //insere o mes no spinner
        FormularioUtil.recuperaValorSpinner(sp_movimentacao_mes,
                DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(),2));
        //insere o ano no spinner
        tv_movimentacao_ano.setText(DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 3));
        //insere o checklist
        if(movimentacao.getEfixa()>0)
            cb_movimentacao_fixa.setChecked(true);
        else
            cb_movimentacao_fixa.setChecked(false);
    }
    /*
    * param: nenhum, retorno: void
    * faz um registro no log das informacoes do objeto salvo
    * */
    private void logObjeto(){
        Log.i(movimentacaoActivity.getString(R.string.operacao_sucesso), "");
        Log.i("Movimentação:", movDescricao);
        Log.i("Movimentação:", movValor);
        Log.i("Movimentação:", movCategorias);
        Log.i("Movimentação:", movDia);
        Log.i("Movimentação:", movMes);
        if(movFixa>0)
            Log.i("Movimentação:", "é fixa");
        else
            Log.i("Movimentação:", "nao é fixa");
    }
    /*
    * param: nenhum, retorno: void
    * insere listener nos elementos da tela
    * */
    private void setListeners(){
        //listener do botao
        bt_movimentacao_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(montaObjeto()){
                    if(movimentacaoDAO.salvar(movimentacao, intencaoDespesa)>0){
                        logObjeto();
                        movimentacaoDAO.close();
                            Intent intent = new Intent(movimentacaoActivity, MovimentacoesActivity.class);
                            intent.putExtra(movimentacaoActivity.getString(R.string.intencaoDespesa),
                                    intencaoDespesa ? true : false);
                            movimentacaoActivity.startActivity(intent);
                        Toast.makeText(
                                movimentacaoActivity,
                                movimentacaoActivity.getString(R.string.operacao_sucesso),
                                Toast.LENGTH_LONG).show();
                        movimentacaoActivity.finish();
                    }else{
                        Toast.makeText(
                                movimentacaoActivity,
                                movimentacaoActivity.getString(R.string.operacao_falha),
                                Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(
                            movimentacaoActivity,
                            movimentacaoActivity.getString(R.string.todos_campos_obrigatorios),
                            Toast.LENGTH_LONG).show();
                }
            }
        });
        //listener do spinner categoria
        sp_movimentacao_categorias.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                movCategorias = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
        //listener do spinner dia
        sp_movimentacao_dia.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                movDia = parent.getItemAtPosition(position).toString();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //listener do spinner mes
        sp_movimentacao_mes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                movMes = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
