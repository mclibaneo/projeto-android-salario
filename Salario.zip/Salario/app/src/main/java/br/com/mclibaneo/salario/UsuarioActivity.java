package br.com.mclibaneo.salario;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import br.com.mclibaneo.salario.dao.UsuarioCateiraDAO;
import br.com.mclibaneo.salario.helper.UsuarioHelper;


public class UsuarioActivity extends MenuActivity {

    private UsuarioHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        helper = new UsuarioHelper(UsuarioActivity.this);
        //insere na tela o usuario caso ele exista
        helper.insereUsuarioTela();
    }

    @Override
    protected void onResume() {
        super.onResume();
        helper.recuperaInformacoesTela();
    }
}
