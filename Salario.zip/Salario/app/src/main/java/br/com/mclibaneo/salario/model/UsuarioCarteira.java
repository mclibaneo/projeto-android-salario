package br.com.mclibaneo.salario.model;

import java.util.List;

public class UsuarioCarteira {

    private Long idUsuarioCarteira;
    private double salarioBruto;
    private double poupanca;
    private List<Movimentacao> despesas;
    private List<Movimentacao> rendas;
    private double salarioLiquido;
    private String nomeUsuario;
    private String emailUsuario;

    public UsuarioCarteira(){}

    public UsuarioCarteira(String nome, String email, Double salarioBruto){
        this.nomeUsuario = nome;
        this.emailUsuario = email;
        this.salarioBruto = salarioBruto;
    }

    public UsuarioCarteira(double salarioBruto, double poupanca, List<Movimentacao> despesas, List<Movimentacao> rendas, double salarioLiquido) {
        this.salarioBruto = salarioBruto;
        this.poupanca = poupanca;
        this.despesas = despesas;
        this.rendas = rendas;
        this.salarioLiquido = salarioLiquido;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public void setEmailUsuario(String email) {
        this.emailUsuario = email;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String usuario) {
        this.nomeUsuario = usuario;
    }

    public Long getIdUsuarioCarteira() {
        return idUsuarioCarteira;
    }

    public void setIdUsuarioCarteira(Long idUsuarioCarteira) {
        this.idUsuarioCarteira = idUsuarioCarteira;
    }

    public List<Movimentacao> getDespesas() {
        return despesas;
    }

    public void setDespesas(List<Movimentacao> despesas) {
        this.despesas = despesas;
    }

    public List<Movimentacao> getRendas() {
        return rendas;
    }

    public void setRendas(List<Movimentacao> rendas) {
        this.rendas = rendas;
    }

    public double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public double getPoupanca() {
        return poupanca;
    }

    public void setPoupanca(double poupanca) {
        this.poupanca = poupanca;
    }

    public double getSalarioLiquido() {
        return salarioLiquido;
    }

    public void setSalarioLiquido(double salarioLiquido) {
        this.salarioLiquido = salarioLiquido;
    }
}
