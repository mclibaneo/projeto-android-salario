package br.com.mclibaneo.salario.dao;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import android.util.Log;

import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.contract.UsuarioCarteiraContract;
import br.com.mclibaneo.salario.model.UsuarioCarteira;


public class UsuarioCateiraDAO {
    private final DataBaseHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;

    /*
    * construtor
    * inicia um construtor contextualizado
    * */
    public UsuarioCateiraDAO(Context context){
        this.context = context;
        this.dbHelper = DataBaseHelper.getInstance(context);
    }
    /*
   * param: Usuario, Carteira, retorno: ContentValues
   * cria um objeto content values para usuario e carteira
   * */
    private ContentValues toValues(UsuarioCarteira uc){
        ContentValues cv = new ContentValues();
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO, uc.getNomeUsuario());
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_EMAIL, uc.getEmailUsuario());
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_SALARIO_BRUTO, uc.getSalarioBruto());
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA, uc.getPoupanca());
        return cv;
    }
    /*
    * param: usuario, carteira, retorno: long
    * insere no banco de dados as informacoes da carteira e do usuario
    * verifica se carteira poupanca ou salario bruto eh para ser alterados
    * retorna valor maior que zero caso seja bem sucedido
    * */

    public long salvar(UsuarioCarteira usuarioCarteira){
        long count = 0;
        //busca os valores e os insere em um contentValue
        ContentValues values = toValues(usuarioCarteira);
        //inicia sessao com banco de dados
        db = dbHelper.getWritableDatabase();
        //realiza operacao para editar
        if(usuarioCarteira.getIdUsuarioCarteira()!=null){
            db = dbHelper.getWritableDatabase();
            String whereClause = UsuarioCarteiraContract.cUsuarioCarteira._ID+"=?";
            String[] whereArgs = {String.valueOf(usuarioCarteira.getIdUsuarioCarteira())};
            count = db.update(
                    UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME, //nome da tabela
                    values, //valores a serem alterados
                    whereClause, //clausula WHERE
                    whereArgs //argumentos da clausula WHERE
            );
            Log.i(context.getString(R.string.log_editou),""+count);
        //realiza operacao de salvar novo
        }else{
            //realiza a insercao no banco de dados
            count = db.insert(
                    UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME, // nome da tabela
                    UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA, // nome da coluna que pode receber valores nulos
                    values //valores a serem inseridos no banco de dados
            );
            Log.i(context.getString(R.string.log_inseriu),""+count);
        }
        return count;
    }
    public Cursor cursorListar(){
        //inicia conexao com banco de dados
        db = dbHelper.getReadableDatabase();
        //indica quais colunas buscar no banco de dados
        String[] projection = {
                UsuarioCarteiraContract.cUsuarioCarteira._ID,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_EMAIL,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_SALARIO_BRUTO,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA
        };
        //retorna a consulta em um cursor
        Cursor c = db.query(
                UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME, //nome da tabela --> String
                projection, // colunas da tabela --> String[]
                null, // colunas para clausula WHERE --> String[]
                null, // valores para clausula WHERE --> String[]
                null, // agrupar as linhas --> String
                null, // filtrar as linhas --> String
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO + " LIMIT 1" // ordernacao --> String + limita a 1 os valores retornados
        );
        return c;
    }
    /*
    * param: nenhum, retorno: UsuarioCarteira
    * retorna o usuario do banco de dados
    * */
    public UsuarioCarteira listar(){
        //cria um usuariocarteira que recebe as informacoes do cursor
        UsuarioCarteira uc = new UsuarioCarteira();
        //recebe um cursor
        Cursor c = cursorListar();
        //move para o primeiro resultado da consulta
        c.moveToFirst();
        //interage dentro do curso e e insere as informacoes dentro do usuario
        uc.setIdUsuarioCarteira(c.getLong(c.getColumnIndexOrThrow(UsuarioCarteiraContract.cUsuarioCarteira._ID)));
        uc.setNomeUsuario(c.getString(c.getColumnIndexOrThrow(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO)));
        uc.setEmailUsuario(c.getString(c.getColumnIndexOrThrow(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_EMAIL)));
        uc.setSalarioBruto(c.getDouble(c.getColumnIndexOrThrow(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_SALARIO_BRUTO)));
        uc.setPoupanca(c.getDouble(c.getColumnIndexOrThrow(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA)));
        //retorna o objeto usuario carteira
        return uc;
    }
    /*
    * param: nenhum, retorno: void
    * fecha a conexao com o banco de dados
    * */
    public void close(){
        dbHelper.close();
    }
    /*
    * param: nenhum, retorno: boolean
    * verifica se usuario existe no banco de dados
    * */
    public boolean usuarioExiste(){
        boolean retorno = false;
        db = dbHelper.getReadableDatabase();
        long count = DatabaseUtils.queryNumEntries(db, UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME);
        if(count>0)
            retorno = true;
        return retorno;
    }
    /*
    * param: usuariocarteira, retorno: long
    * remove o usuario do banco de dados
    * */
    public long remover(UsuarioCarteira usuarioCarteira){
        long count = 0;
        db = dbHelper.getWritableDatabase();
        String whereClause = UsuarioCarteiraContract.cUsuarioCarteira._ID+"=?";
        String[] whereArgs = {String.valueOf(usuarioCarteira.getIdUsuarioCarteira())};
        count = db.delete(
                UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME, //nome da tabela
                whereClause, //clausula WHERE
                whereArgs //argumentos da clausula WHERE
        );
        return count;
    }
}
