package br.com.mclibaneo.salario.dao;

import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.util.Log;

import br.com.mclibaneo.salario.contract.UsuarioCarteiraContract;
import br.com.mclibaneo.salario.model.Carteira;
import br.com.mclibaneo.salario.model.Usuario;


public class UsuarioCateiraDAO {
    private final DataBaseHelper dbHelper;
    private SQLiteDatabase db;
    private Context context;
    /*
    * construtor
    * inicia um construtor contextualizado
    * */
    public UsuarioCateiraDAO(Context context){
        this.context = context;
        this.dbHelper = DataBaseHelper.getInstance(context);
    }
    /*
    * param: usuario, carteira, retorno: long
    * insere no banco de dados as informacoes da carteira e do usuario
    * verifica se carteira poupanca ou salario bruto eh para ser alterados
    * retorna valor maior que zero caso seja bem sucedido
    * */
    public long salvar(Usuario usuario, Carteira carteira){
        long retorno = 0;
        //busca os valores e os insere em um contentValue
        ContentValues values = toValues(usuario, carteira);
        //inicia sessao com banco de dados
        db = dbHelper.getWritableDatabase();
        //realiza operacao para editar
        if(usuario.getIdUsuario()!=null && carteira.getIdCarteira()!= null){
            Log.i("Editar Usuário: ",usuario.getNome());
        //realiza operacao de salvar novo
        }else{
            //realiza a insercao no banco de dados
            retorno = db.insert(
                    UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME, // nome da tabela
                    UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA, // nome da coluna que pode receber valores nulos
                    values //valores a serem inseridos no banco de dados
            );
            Log.i("Novo Usuário: ",usuario.getNome());
        }
        return retorno;
    }
    public Cursor cursorListar(){
        //inicia conexao com banco de dados
        db = dbHelper.getReadableDatabase();
        //indica quais colunas buscar no banco de dados
        String[] projection = {
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_EMAIL,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_SALARIO_BRUTO,
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA
        };
        //retorna a consulta em um cursor
        Cursor c = db.query(
                UsuarioCarteiraContract.cUsuarioCarteira.TABLE_NAME, //nome da tabela --> String
                projection, // colunas da tabela --> String[]
                null, // colunas para clausula WHERE --> String[]
                null, // valores para clausula WHERE --> String[]
                null, // agrupar as linhas --> String
                null, // filtrar as linhas --> String
                UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO // ordernacao --> String
        );
        return c;
    }
    /*
    * param: Usuario, Carteira, retorno: ContentValues
    * cria um objeto content values para usuario e carteira
    * */
    private ContentValues toValues(Usuario usuario, Carteira carteira){
        ContentValues cv = new ContentValues();
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_USUARIO, usuario.getNome());
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_EMAIL, usuario.getEmail());
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_SALARIO_BRUTO, carteira.getSalarioBruto());
        cv.put(UsuarioCarteiraContract.cUsuarioCarteira.COLUMN_NAME_POUPANCA, carteira.getPoupanca());
        return cv;
    }
    /*
    * param: nenhum, retorno: void
    * fecha a conexao com o banco de dados
    * */
    public void close(){
        dbHelper.close();
    }


}
