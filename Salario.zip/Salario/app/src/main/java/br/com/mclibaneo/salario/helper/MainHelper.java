package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.UsuarioActivity;
import br.com.mclibaneo.salario.dao.MovimentacaoDAO;
import br.com.mclibaneo.salario.dao.UsuarioCateiraDAO;
import br.com.mclibaneo.salario.model.Data;
import br.com.mclibaneo.salario.model.Movimentacao;
import br.com.mclibaneo.salario.model.UsuarioCarteira;
import br.com.mclibaneo.salario.util.DataUtil;
import br.com.mclibaneo.salario.util.FormularioUtil;

public class MainHelper extends Activity {

    private Activity mainActivity;
    private UsuarioCateiraDAO usuarioCateiraDAO;
    private MovimentacaoDAO movimentacaoDAO;
    private UsuarioCarteira usuarioCarteira;
    private ArrayList<Movimentacao> listaDespesasMes;
    private ArrayList<Movimentacao> listaReceitasMes;
    private ArrayList<Movimentacao> listaDespesasMesFixa;
    private ArrayList<Movimentacao> listaReceitasMesFixa;
    private ArrayList<Movimentacao> listaDespesasMesPassadoFixa;
    private ArrayList<Movimentacao> listaReceitasMesPassadoFixa;
    private double valorDespesasMes;
    private double valorReceitasMes;
    private boolean usuarioExiste;

    private TextView tv_main_nome;
    private TextView tv_main_data;
    private TextView tv_main_saldo_atual;
    private TextView tv_main_despesa_atual;

    private ListView lv_main_despesas;

    /*
    * criando um construtor contextualizado
    * */
    public MainHelper(Activity activity){
        this.mainActivity = activity;
        this.usuarioCateiraDAO = new UsuarioCateiraDAO(activity);
        this.movimentacaoDAO = new MovimentacaoDAO(activity);
        recuperaInformacoesTela();
        insereInformacoesTela();
    }
    /*
    * param: nenhum, retorno void
    * recupera os valores das views da tela
    * */
    private void recuperaInformacoesTela(){
        this.tv_main_nome = (TextView) mainActivity.findViewById(R.id.tv_main_nome);
        this.tv_main_data = (TextView) mainActivity.findViewById(R.id.tv_main_data);
        this.tv_main_despesa_atual = (TextView) mainActivity.findViewById(R.id.tv_main_despesa_atual);
        this.tv_main_saldo_atual = (TextView) mainActivity.findViewById(R.id.tv_main_saldo_atual);
        this.lv_main_despesas = (ListView) mainActivity.findViewById(R.id.lv_main_despesas);
    }
    /*
    * param: nenhum, retorno: void
    * insere informacoes na tela caso o usuario exista
    * */
    public void insereInformacoesTela(){
        //verifica se o usuario existe
        this.usuarioExiste = usuarioCateiraDAO.usuarioExiste();
        if(usuarioExiste){
            recuperaInformacoesBanco();
            //verifica salario bruto do mes
            verificaSalarioBruto();
            //adiciona as receitas fixas deste mes
            verificaReceitasFixasMes();
            //adiciona as despesas fixas deste mes
            verificaDespesasFixasMes();
            //informa a data
            tv_main_data.setText(DataUtil.getDataFormatadaBrasil());
            //informa o nome do usuario
            tv_main_nome.setText(usuarioCarteira.getNomeUsuario());
            //insere o saldo atual
            insereSaldoAtual();
            //insere a despesa atual
            insereDespesaAtual();
            //insere lista de despesas
            insereListaDespesas();
        }else{
            //se nao houver usuario passa para activity UsuarioCarteira para ser criado usuario novo
            Intent intent = new Intent(mainActivity, UsuarioActivity.class);
            intent.putExtra(mainActivity.getString(R.string.usuarioNovo), true);
            mainActivity.startActivity(intent);
            usuarioExiste = false;
        }

    }
    /*
   * param: nenhum, retorno: void
   * recupera as informacoes do banco de dados e as adiciona nas varaiveis
   * */
    private void recuperaInformacoesBanco(){
        this.usuarioCarteira = usuarioCateiraDAO.listar();
        this.listaDespesasMes = movimentacaoDAO.listar(true, false, false, false);
        this.listaReceitasMes = movimentacaoDAO.listar(false, false, false, false);
        this.listaDespesasMesFixa = movimentacaoDAO.listar(true, false, true, false);
        this.listaReceitasMesFixa = movimentacaoDAO.listar(false, false, true, false);
        this.listaDespesasMesPassadoFixa = movimentacaoDAO.listar(true, false, true, true);
        this.listaReceitasMesPassadoFixa = movimentacaoDAO.listar(false, false, true, true);
        this.valorDespesasMes = movimentacaoDAO.getSomaValoresMovimentacoes(true, false);
        this.valorReceitasMes = movimentacaoDAO.getSomaValoresMovimentacoes(false, false);
        //fecha conexao com banco de dados
        movimentacaoDAO.close();
        usuarioCateiraDAO.close();
    }
    /*
    * param: nenhum, retorno: void
    * passa para o formulario util a funcao de popular a listview
    * com informacoes das depesas do banco de dados
    * */
    private void insereListaDespesas(){
        FormularioUtil.retornaListViewPopulado(lv_main_despesas, mainActivity, listaDespesasMes);
    }
    /*
   * param: nenhum, retorno: void
   * obtem o salario bruto e soma com as receitas do mes
   * e subtrai as despesas do mes
   * */
    private void insereSaldoAtual(){
        double saldoAtual = (valorReceitasMes) - valorDespesasMes;
        tv_main_saldo_atual.setText(mainActivity.getString(R.string.main_monetario) + saldoAtual + "");
    }
    /*
   * param: nenhum, retorno: void
   * obtem a despesa atual do banco de dados
   * */
    private void insereDespesaAtual(){
        tv_main_despesa_atual.setText(mainActivity.getString(R.string.main_monetario) + valorDespesasMes);
    }
    /*
    * param: nenhum; retorno: void
    * verifica se o salario bruta ja eh uma despesa fixa,
    * se nao for o adiciona como despesa fixa do mes
    * se ja for atualiza o valor de acordo com o valor do UsuarioCarteira
    * */
    private void verificaSalarioBruto(){
        //verifica se ha salario bruto como despesa fixa
        if(movimentacaoDAO.retornaMovimentacaoSalarioBrutoBanco()!=null){
            //atualiza valor da movimentacao
            movimentacaoDAO.atualizaValorSalarioBrutoBanco(usuarioCarteira.getSalarioBruto());
        }else{
            //se nao houver, adiciona salario bruto como despesa fixa
            movimentacaoDAO.salvar(retornaMovimentacaoSalarioBruto(), false);
        }
    }
    /*
    * param: nenhum; retorno: movimentacao - salario bruto
    * monta objeto salario bruto para ser inserido como despesa fixa
    * */
    private Movimentacao retornaMovimentacaoSalarioBruto(){
        Movimentacao salarioBruto = new Movimentacao();
        salarioBruto.setDescricaoMovimentacao(mainActivity.getString(R.string.salario_bruto));
        salarioBruto.setEfixa(1);
        salarioBruto.setValorMovimentacao(usuarioCarteira.getSalarioBruto());
        salarioBruto.setCategoriaMovimentacao(mainActivity.getString(R.string.receita));
        String data = DataUtil.getAno()+ "-"+
                DataUtil.retornaMesFormatoBanco(DataUtil.getMes()+1)+"-01 00:01";
        salarioBruto.setDataMovimentacaoString(data);
        return salarioBruto;
    }
    /*
    * param: nenhum; retorno: void
    * verifica se o dia eh primeiro, verifica se no mes ha despesas fixas, se nao houver, adiciona
    * as despesas fixas do mes passado no mes atual
    * */
    private void verificaDespesasFixasMes(){
        if(listaDespesasMesFixa.size() <=0){
            if(listaDespesasMesPassadoFixa!=null){
                for (Movimentacao movimentacao : listaDespesasMesPassadoFixa){
                    Movimentacao movimentacaoFixa = new Movimentacao();
                    movimentacaoFixa.setCategoriaMovimentacao(movimentacao.getCategoriaMovimentacao());
                    movimentacaoFixa.setDescricaoMovimentacao(movimentacao.getDescricaoMovimentacao());
                    movimentacaoFixa.setEfixa(movimentacao.getEfixa());
                    movimentacaoFixa.setValorMovimentacao(movimentacao.getValorMovimentacao());
                    //muda a data para o mes seguinte
                    Integer mes = DataUtil.getMes() + 1;
                    String dataMesSeguinte =  DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 3)+
                            "-"+DataUtil.retornaMesFormatoBanco(mes)+
                            "-"+DataUtil.retornaDiaMesFormatoBanco(Integer.parseInt(DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 1)))+
                            " "+DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 4);
                    movimentacaoFixa.setDataMovimentacaoString(dataMesSeguinte);
                    movimentacaoDAO.salvar(movimentacaoFixa, true);
                }
            }
        }
    }
    /*
   * param: nenhum; retorno: void
   * verifica se o dia eh primeiro, verifica se no mes ha receitas fixas, se nao houver, adiciona
   * as receitas fixas do mes passado no mes atual
   * */
    private void verificaReceitasFixasMes(){
        if(listaReceitasMesFixa.size() <=0){
            if(listaReceitasMesPassadoFixa!=null){
                for (Movimentacao movimentacao : listaReceitasMesPassadoFixa){
                    Movimentacao movimentacaoFixa = new Movimentacao();
                    movimentacaoFixa.setCategoriaMovimentacao(movimentacao.getCategoriaMovimentacao());
                    movimentacaoFixa.setDescricaoMovimentacao(movimentacao.getDescricaoMovimentacao());
                    movimentacaoFixa.setEfixa(movimentacao.getEfixa());
                    movimentacaoFixa.setValorMovimentacao(movimentacao.getValorMovimentacao());
                    //muda a data para o mes seguinte
                    Integer mes = DataUtil.getMes() + 1;
                    String dataMesSeguinte =  DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 3)+
                            "-"+DataUtil.retornaMesFormatoBanco(mes)+
                            "-"+DataUtil.retornaDiaMesFormatoBanco(Integer.parseInt(DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 1)))+
                            " "+DataUtil.getDiaMesAnoDataBanco(movimentacao.getDataMovimentacaoString(), 4);
                    movimentacaoFixa.setDataMovimentacaoString(dataMesSeguinte);
                    movimentacaoDAO.salvar(movimentacaoFixa, false);
                }
            }
        }
    }
}
