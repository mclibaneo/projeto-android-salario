package br.com.mclibaneo.salario.model;

/**
 * Created by 121101 on 15/04/2016.
 */
public class Usuario {

    private Long idUsuario;
    private String nome;
    private String email;
    private Carteira carteira;

    public Usuario(){}

    public Usuario(String nome, String email, Carteira carteira) {
        this.nome = nome;
        this.email = email;
        this.carteira = carteira;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Carteira getCarteira() {
        return carteira;
    }

    public void setCarteira(Carteira carteira) {
        this.carteira = carteira;
    }
}
