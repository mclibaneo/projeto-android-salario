package br.com.mclibaneo.salario.adapter;

import android.app.ListActivity;
import android.os.Bundle;

import java.util.ArrayList;

import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.model.Categoria;

/**
 * Created by 121101 on 26/04/2016.
 */
public class ListaCategorias extends ListActivity{
    private CategoriaDAO dao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_categorias);
        ArrayList<Categoria> categorias = new ArrayList<Categoria>();
    }
}
