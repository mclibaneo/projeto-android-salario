package br.com.mclibaneo.salario.contract;

import android.provider.BaseColumns;

public final class CategoriaContract {
    public CategoriaContract(){}

    public static abstract class cCategoria implements BaseColumns{
        public static final String TABLE_NAME = "categoria";
        public static final String COLUMN_NAME_ID = "id_categoria";
        public static final String COLUMN_NAME_NAME = "nome_categoria";
        public static final String COLUMN_NAME_PAI = "nome_categoria_pai";

        public static final String COMMA_SEP = ",";
        public static final String SEP = " ";

        public static final String SQL_CREATE_TABLE_CATEGORIA = "CREATE TABLE"+SEP+cCategoria.TABLE_NAME+"("+
                cCategoria._ID+SEP+"INTEGER PRIMARY KEY"+COMMA_SEP+SEP+
                cCategoria.COLUMN_NAME_NAME+SEP+"TEXT UNIQUE NOT NULL"+COMMA_SEP+SEP+
                cCategoria.COLUMN_NAME_PAI+SEP+"TEXT"+")";

        public static final String SQL_DELETE_TABLE_CATEGORIA = "DROP TABLE IF EXISTS"+SEP+cCategoria.TABLE_NAME;

    }
}
