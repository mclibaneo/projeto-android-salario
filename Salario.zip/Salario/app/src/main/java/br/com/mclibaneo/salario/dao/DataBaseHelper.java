package br.com.mclibaneo.salario.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import br.com.mclibaneo.salario.contract.CategoriaContract;
import br.com.mclibaneo.salario.contract.UsuarioCarteiraContract;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static DataBaseHelper sInstance;
    private static final String DATABASE_NAME = "salario_db";
    private static final int DATABASE_VERSION = 1;

    public static synchronized DataBaseHelper getInstance(Context context){
        if(sInstance == null){
            sInstance = new DataBaseHelper(context.getApplicationContext());
        }
        return sInstance;
    }

    private DataBaseHelper(Context context){
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CategoriaContract.cCategoria.SQL_CREATE_TABLE_CATEGORIA);
        db.execSQL(UsuarioCarteiraContract.cUsuarioCarteira.SQL_CREATE_TABLE_USUARIO_CARTEIRA);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(CategoriaContract.cCategoria.SQL_DELETE_TABLE_CATEGORIA);
        db.execSQL(UsuarioCarteiraContract.cUsuarioCarteira.SQL_DELETE_TABLE_USUARIO_CARTEIRA);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
