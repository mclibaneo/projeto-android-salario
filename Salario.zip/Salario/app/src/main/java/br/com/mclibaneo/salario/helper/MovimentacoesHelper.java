package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

import br.com.mclibaneo.salario.MovimentacaoActivity;
import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.MovimentacaoDAO;
import br.com.mclibaneo.salario.model.Movimentacao;
import br.com.mclibaneo.salario.util.FormularioUtil;

public class MovimentacoesHelper extends Activity{
    private Activity despesasActivity;
    private ActionMode mActionMode;

    private TextView tv_titulo;
    private ListView lv_despesas;
    private CheckBox cb_movimentacoes;

    private Movimentacao movimentacao;

    private MovimentacaoDAO movimentacaoDAO;

    private boolean intencaoDespesa;
    private ArrayList<Movimentacao> listaMovimentacoes;

    public MovimentacoesHelper(Activity activity){
        this.despesasActivity = activity;
        movimentacaoDAO = new MovimentacaoDAO(activity);

        recuperaInformacoesTela();
        recuperaIntentExtra();
        setListeners();
    }
    /*
    * param: nenhum, retorno: void
    * recupera as informacoes dos elementos da view
    * */
    public void recuperaInformacoesTela(){
        this.lv_despesas = (ListView) despesasActivity.findViewById(R.id.lv_despesas);
        this.tv_titulo = (TextView) despesasActivity.findViewById(R.id.tv_movimentacoes);
        this.cb_movimentacoes = (CheckBox) despesasActivity.findViewById(R.id.cb_movimentacoes);
    }
    /*
    * param: nanhum, retorno: void
    * recupera os extras e a intencao passada pela activity
    * e insere as informacoes na tela de acordo com a intent
    * */
    public void recuperaIntentExtra(){
        this.intencaoDespesa = despesasActivity.getIntent().getBooleanExtra(despesasActivity.getString(R.string.intencaoDespesa), true);
        insereInformacoesTela();
        if(intencaoDespesa){
            tv_titulo.setText(despesasActivity.getString(R.string.movimentacoes_titulo_despesas));
        }else{
            tv_titulo.setText(despesasActivity.getString(R.string.movimentacoes_titulo_receitas));
        }
    }
    /*
   * param: nenhum, retorno: void
   * insere informacoes na tela
   * */
    public void insereInformacoesTela(){
        //insere a listview preenchida na tela conforme checkbox total
        if(cb_movimentacoes.isChecked())
            FormularioUtil.retornaListViewPopulado(lv_despesas, despesasActivity, getListaMovimentacoes(true));
        else
            FormularioUtil.retornaListViewPopulado(lv_despesas, despesasActivity, getListaMovimentacoes(false));
    }
    /*
    * param: nenhum, retorno? List<Movimentacao>
    * retorna uma lista do banco com as movimentacoes
    * verifica se eh do mes ou total
    * */
    public ArrayList<Movimentacao> getListaMovimentacoes(boolean total){
        this.listaMovimentacoes = movimentacaoDAO.listar(intencaoDespesa, total);
        movimentacaoDAO.close();
        return listaMovimentacoes;
    }
    /*
    * param: nenhum, retorno: void
    * Adiciona Listeners nos elementos da activity
    * */
    private void setListeners(){
        lv_despesas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(despesasActivity, "Item:" + parent.getItemAtPosition(position), Toast.LENGTH_LONG).show();
            }
        });
        lv_despesas.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                movimentacao = (Movimentacao) parent.getItemAtPosition(position);
                Log.i("ITEM:", "" + movimentacao);
                if (mActionMode != null) {
                    return false;
                }
                mActionMode = despesasActivity.startActionMode(mActionModeCallback);
                view.setSelected(true);
                return true;
            }
        });
        cb_movimentacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insereInformacoesTela();
            }
        });
    }
    /*
    * param: nenhum, retorno: ActionMode
    * Inicia um ActionMode para criar um menu de contexto na action bar
    * */
    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback(){

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.menu_context_categorias, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()){
                case R.id.menu_context_editar:
                    //editar categoria selecionada
                    Intent intent = new Intent(despesasActivity, MovimentacaoActivity.class);
                    intent.putExtra(despesasActivity.getString(R.string.movimentacao), movimentacao);
                    intent.putExtra(despesasActivity.getString(R.string.intencaoDespesa), intencaoDespesa);
                    despesasActivity.startActivity(intent);
                    mode.finish();
                    return true;
                case R.id.menu_context_apagar:
                    //apagar categoria selecionada
                    movimentacaoDAO.remover(movimentacao, intencaoDespesa);
                    movimentacaoDAO.close();
                    insereInformacoesTela();
                    mode.finish();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;
        }
    };
}
