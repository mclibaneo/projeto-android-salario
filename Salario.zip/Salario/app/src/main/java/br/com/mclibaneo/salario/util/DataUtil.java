package br.com.mclibaneo.salario.util;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Locale;

import br.com.mclibaneo.salario.model.Data;


/**
 * Created by 121101 on 15/04/2016.
 */
public class DataUtil {
    private static Data data;
    private static Calendar calendario;

   public static String getData(){
       calendario = Calendar.getInstance();
       Locale brasil = new Locale("pt", "BR");
       DateFormat formata = DateFormat.getDateInstance(DateFormat.FULL, brasil);
       System.out.println(calendario.getTime());
       return formata.format(calendario.getTime());
    }
}
