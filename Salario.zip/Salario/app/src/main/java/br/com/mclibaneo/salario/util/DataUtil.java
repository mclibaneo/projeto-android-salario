package br.com.mclibaneo.salario.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import br.com.mclibaneo.salario.model.Data;

public class DataUtil {
    private static Data data;
    private static Calendar calendario;

    public static Locale getLocaleBrasil(){
        return new Locale("pt", "BR");
    }

    public static Calendar getDateBrasil(){
        return calendario = GregorianCalendar.getInstance(getLocaleBrasil());
    }
   public static String getDataFormatadaBrasil(){
       DateFormat formata = DateFormat.getDateInstance(DateFormat.FULL, getLocaleBrasil());
       return formata.format(getDateBrasil().getTime());
    }

    public static int getAno(){
        return getDateBrasil().get(Calendar.YEAR);
    }
    public static int getDiaDoMes() {
        return getDateBrasil().get(Calendar.DAY_OF_MONTH);
    }
    public static int getMes(){return getDateBrasil().get(Calendar.MONTH);}

    public static String criaDataBanco(String ano, String mes, String dia){
        String dataBanco;
        int year = Integer.parseInt(ano);
        int month = getMonthInt(mes);
        int day = Integer.parseInt(dia);

        Calendar data = getDateBrasil();
        data.set(year, month, day);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        dataBanco = sdf.format(data.getTimeInMillis());

        return dataBanco;
    }

    public static String getMesExtenso(int mesInt){
        String mes = "";
            switch (mesInt){
                case 0:
                    mes="Janeiro";
                    break;
                case 1:
                    mes="Fevereiro";
                    break;
                case 2:
                    mes="Março";
                    break;
                case 3:
                    mes="Abril";
                    break;
                case 4:
                    mes="Maio";
                    break;
                case 5:
                    mes="Junho";
                    break;
                case 6:
                    mes="Julho";
                    break;
                case 7:
                    mes="Agosto";
                    break;
                case 8:
                    mes="Setembro";
                    break;
                case 9:
                    mes="Outubro";
                    break;
                case 10:
                    mes="Novembro";
                    break;
                case 11:
                    mes="Dezembro";
                    break;
                default:
                    mes="Janeiro";
                    break;
            }
        return mes;
    }
    /*
    * param: string, retorno: int
    * retorna o valor inteiro do mes extenso
    * */
    public static int getMonthInt(String mesString){
        int mes = 0;
        switch (mesString){
            case "Janeiro":
                mes=0;
                break;
            case "Fevereiro":
                mes=1;
                break;
            case "Março":
                mes=2;
                break;
            case "Abril":
                mes=3;
                break;
            case "Maio":
                mes=4;
                break;
            case "Junho":
                mes=5;
                break;
            case "Julho":
                mes=6;
                break;
            case "Agosto":
                mes=7;
                break;
            case "Setembro":
                mes=8;
                break;
            case "Outubro":
                mes=9;
                break;
            case "Novembro":
                mes=10;
                break;
            case "Dezembro":
                mes=11;
                break;
            default:
                mes=0;
                break;
        }
        return mes;
    }
    /*
    * param: nenhum; retorno String com data do inicio do mes
    * retorna uma string com data do inicio do mes no formato do banco de dados
    * */
    public static String getDataInicioMes(){
        String retorno = getAno()+"-0"+(getMes()+1)+"-"+"01"+" "+"00:01";
        if(getMes() == 10)
            retorno = getAno()+"-11-"+"01"+" "+"00:01";
        if(getMes() == 11)
            retorno = getAno()+"-12-"+"01"+" "+"00:01";
        return retorno;
    }
    /*
    * param: nenhum; retorno String com data do fim do mes
    * retorna uma string com data do fim do mes no formato do banco de dados
    * */
    public static String getDataFimMes(){
        String retorno = getAno()+"-0"+(getMes()+2)+"-"+"01"+" "+"00:01";
        if(getMes() == 10)
            retorno = getAno()+"-12-"+"01"+" "+"00:01";
        if(getMes() == 11)
            retorno = getAno()+1+"-01-"+"01"+" "+"00:01";
        return retorno;
    }
    /*
    * param: nenhum; retorno String com data do inicio do mes
    * retorna uma string com data do inicio do mes passado no formato do banco de dados
    * */
    public static String getDataInicioMesPassado(){
        String retorno = getAno()+"-0"+(getMes())+"-"+"01"+" "+"00:01";
        if(getMes() == 0)
            retorno = getAno()-1+"-01-"+"01"+" "+"00:01";
        return retorno;
    }
    /*
    * param: nenhum; retorno String com data do fim do mes
    * retorna uma string com data do fim do mes passado no formato do banco de dados
    * */
    public static String getDataFimMesPassado(){
        String retorno = getDataInicioMes();
        return retorno;
    }
    /*
    * param: String data do banco, int dia, mes ou ano; retorno: String
    * recebe uma data do banco, a separa e retorna o dia, mes ou ano
    * */
    public static String getDiaMesAnoDataBanco(String data, int opcao){
        String retorno = "";
        //pega a data no formato 'YYYY-mm-dd HH:mm' e salva em array{'YYYY-mm-dd', 'HH:mm'}
        String[] dataHora = data.split(" ");
        //pega o ano YYYY
        String ano = dataHora[0].split("-")[0];
        //pega o mes mm e subtitui o zero por nada retornando apenas um digito
        String mes = dataHora[0].split("-")[1];
        if(!mes.equals("10"))
            mes = mes.replace("0","");
        //pega o dia dd
        String dia = dataHora[0].split("-")[2];
        //substitui o zero por nada nos primeiros dias
        if(!(dia.equals("10") || dia.equals("20") || dia.equals("30")))
            dia = dia.replace("0", "");
        switch (opcao){
            case 1:
                retorno = dia;
                break;
            case 2:
                retorno = mes;
                break;
            case 3:
                retorno = ano;
                break;
            case 4:
                retorno = dataHora[1];
                break;
            case 123:
                retorno = dataHora[0];
                break;
            default:
                break;
        }
        return retorno;
    }
    /*
    * param: String data do banco, int dia, mes ou ano; retorno: String
    * recebe uma data do banco, e a formata para ser apresentada
    * */
    public static String retornaDataBancoFormatada(String data, boolean extensa){
        String retorno = "";
        //pega a data no formato 'YYYY-mm-dd HH:mm' e salva em array{'YYYY-mm-dd', 'HH:mm'}
        String[] dataHora = data.split(" ");
        //pega o ano YYYY
        String ano = dataHora[0].split("-")[0];
        //pega o mes mm e subtitui o zero por nada retornando apenas um digito
        String mes = dataHora[0].split("-")[1];
        if(!mes.equals("10"))
            mes = mes.replace("0","");
        //pega o dia dd
        String dia = dataHora[0].split("-")[2];
        //substitui o zero por nada nos primeiros dias
        if(!(dia.equals("10") || dia.equals("20") || dia.equals("30")))
            dia = dia.replace("0", "");
       if(extensa)
           retorno = dia+"/"+mes+"/"+ano+" às "+dataHora[1];
        retorno = dia+"/"+mes+"/"+ano;
        return retorno;
    }
    /*
    * param: int dia; retorno: String
    * retorna dia formatado para ser inserido no banco
    * */
    public static String retornaDiaMesFormatoBanco(int dia){
        String retorno = ""+dia;
        if(dia<10){
            retorno = "0"+dia;
        }
        return retorno;
    }
    /*
    * param: int dia; retorno: String
    * retorna dia formatado para ser inserido no banco
    * */
    public static String retornaMesFormatoBanco(int mes){
        String retorno = ""+mes;
        if(mes<10){
            retorno = "0"+mes;
        }
        return retorno;
    }
}
