package br.com.mclibaneo.salario.model;

import java.io.Serializable;
import java.util.List;

public class Carteira implements Serializable {


    private Long idCarteira;
    private double salarioBruto;
    private double poupanca;
    private List<Movimentacao> despesas;
    private List<Movimentacao> rendas;
    private double salarioLiquido;

    public Carteira(double salarioBruto){
        this.salarioBruto = salarioBruto;
    }

    public Carteira(double salarioBruto, double poupanca, List<Movimentacao> despesas, List<Movimentacao> rendas, double salarioLiquido) {
        this.salarioBruto = salarioBruto;
        this.poupanca = poupanca;
        this.despesas = despesas;
        this.rendas = rendas;
        this.salarioLiquido = salarioLiquido;
    }

    public Long getIdCarteira() {
        return idCarteira;
    }

    public void setIdCarteira(Long idCarteira) {
        this.idCarteira = idCarteira;
    }

    public List<Movimentacao> getDespesas() {
        return despesas;
    }

    public void setDespesas(List<Movimentacao> despesas) {
        this.despesas = despesas;
    }

    public List<Movimentacao> getRendas() {
        return rendas;
    }

    public void setRendas(List<Movimentacao> rendas) {
        this.rendas = rendas;
    }

    public double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public double getPoupanca() {
        return poupanca;
    }

    public void setPoupanca(double poupanca) {
        this.poupanca = poupanca;
    }

    public double getSalarioLiquido() {
        return salarioLiquido;
    }

    public void setSalarioLiquido(double salarioLiquido) {
        this.salarioLiquido = salarioLiquido;
    }
}
