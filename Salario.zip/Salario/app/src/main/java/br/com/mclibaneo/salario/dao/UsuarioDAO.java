package br.com.mclibaneo.salario.dao;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import br.com.mclibaneo.salario.model.Usuario;
import br.com.mclibaneo.salario.util.ConstantesUtil;

/**
 * Created by 121101 on 18/04/2016.
 */
public class UsuarioDAO {
    private final DataBaseHelper dbHelper;
    private SQLiteOpenHelper db;
    private Context context;

    public UsuarioDAO(Context context){
        this.context = context;
        this.dbHelper = DataBaseHelper.getInstance(context);
    }

    public void salvar(Usuario usuario){
        ConstantesUtil.setNomeUsuario(usuario.getNome());
        Toast.makeText(this.context, "Salvar <usuario>: "+usuario.getNome(), Toast.LENGTH_SHORT).show();

    }
}
