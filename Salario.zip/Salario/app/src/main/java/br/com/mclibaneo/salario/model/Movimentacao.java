package br.com.mclibaneo.salario.model;

import java.util.Calendar;

/**
 * Created by 121101 on 15/04/2016.
 */
public class Movimentacao {
    private Long idMovimentacao;
    private Calendar dataMovimentacao;
    private double valorMovimentacao;
    private boolean eFixo;
    private String descricaoMovimentacao;
    private Categoria categoriaMovimentacao;

    public Movimentacao(Calendar dataMovimentacao, double valorMovimentacao, boolean eFixo, String descricaoMovimentacao, Categoria categoriaMovimentacao) {
        this.dataMovimentacao = dataMovimentacao;
        this.valorMovimentacao = valorMovimentacao;
        this.eFixo = eFixo;
        this.descricaoMovimentacao = descricaoMovimentacao;
        this.categoriaMovimentacao = categoriaMovimentacao;
    }

    public Long getIdMovimentacao() {
        return idMovimentacao;
    }

    public void setIdMovimentacao(Long idMovimentacao) {
        this.idMovimentacao = idMovimentacao;
    }

    public Calendar getDataMovimentacao() {
        return dataMovimentacao;
    }

    public void setDataMovimentacao(Calendar dataMovimentacao) {
        this.dataMovimentacao = dataMovimentacao;
    }

    public double getValorMovimentacao() {
        return valorMovimentacao;
    }

    public void setValorMovimentacao(double valorMovimentacao) {
        this.valorMovimentacao = valorMovimentacao;
    }

    public boolean iseFixo() {
        return eFixo;
    }

    public void seteFixo(boolean eFixo) {
        this.eFixo = eFixo;
    }

    public String getDescricaoMovimentacao() {
        return descricaoMovimentacao;
    }

    public void setDescricaoMovimentacao(String descricaoMovimentacao) {
        this.descricaoMovimentacao = descricaoMovimentacao;
    }

    public Categoria getCategoriaMovimentacao() {
        return categoriaMovimentacao;
    }

    public void setCategoriaMovimentacao(Categoria categoriaMovimentacao) {
        this.categoriaMovimentacao = categoriaMovimentacao;
    }
}
