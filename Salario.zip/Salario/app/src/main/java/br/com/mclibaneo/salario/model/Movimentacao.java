package br.com.mclibaneo.salario.model;

import java.io.Serializable;

public class Movimentacao implements Serializable {
    private Long idMovimentacao;
    private double valorMovimentacao;
    private String descricaoMovimentacao;
    private String categoriaMovimentacao;
    private String dataMovimentacaoString;
    private int efixa;

    public Movimentacao(){}

    public String getDataMovimentacaoString() {
        return dataMovimentacaoString;
    }

    public void setDataMovimentacaoString(String dataMovimentacaoString) {
        this.dataMovimentacaoString = dataMovimentacaoString;
    }

    public int getEfixa() {
        return efixa;
    }

    public void setEfixa(int efixa) {
        this.efixa = efixa;
    }

    public Long getIdMovimentacao() {
        return idMovimentacao;
    }

    public void setIdMovimentacao(Long idMovimentacao) {
        this.idMovimentacao = idMovimentacao;
    }

    public double getValorMovimentacao() {
        return valorMovimentacao;
    }

    public void setValorMovimentacao(double valorMovimentacao) {
        this.valorMovimentacao = valorMovimentacao;
    }

    public String getDescricaoMovimentacao() {
        return descricaoMovimentacao;
    }

    public void setDescricaoMovimentacao(String descricaoMovimentacao) {
        this.descricaoMovimentacao = descricaoMovimentacao;
    }

    public String getCategoriaMovimentacao() {
        return categoriaMovimentacao;
    }

    public void setCategoriaMovimentacao(String categoriaMovimentacao) {
        this.categoriaMovimentacao = categoriaMovimentacao;
    }

    @Override
    public String toString() {
        return getDataMovimentacaoString()+" - "+getDescricaoMovimentacao() +" R$ "+getValorMovimentacao();
    }
}
