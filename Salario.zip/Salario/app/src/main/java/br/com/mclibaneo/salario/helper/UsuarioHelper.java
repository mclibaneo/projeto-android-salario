package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;

import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.UsuarioDAO;
import br.com.mclibaneo.salario.model.Carteira;
import br.com.mclibaneo.salario.model.Usuario;
import br.com.mclibaneo.salario.util.FormularioUtil;

public class UsuarioHelper extends Activity{

    private Activity usuarioActivity;

    private EditText et_usuario_nome;
    private EditText et_usuario_email;
    private EditText et_usuario_salario;

    private String usuarioNome;
    private String usuarioEmail;
    private String usuarioSalario;

    private Button bt_usuario_salvar;

    private Usuario usuarioFormulario;
    private UsuarioDAO usuarioDAO;

    public UsuarioHelper(Activity activity){
        this.usuarioActivity = activity;
        this.usuarioFormulario = new Usuario();
        this.usuarioDAO = new UsuarioDAO(activity);
        this.bt_usuario_salvar = (Button) activity.findViewById(R.id.bt_usuario_salvar);
    }

    private void recuperaInformacoesTela(){
        this.et_usuario_email = (EditText) usuarioActivity.findViewById(R.id.et_usuario_email);
        this.et_usuario_nome = (EditText) usuarioActivity.findViewById(R.id.et_usuario_nome);
        this.et_usuario_salario = (EditText) usuarioActivity.findViewById(R.id.et_usuario_salario);

        this.usuarioNome = et_usuario_nome.getText().toString();
        this.usuarioEmail = et_usuario_email.getText().toString();
        this.usuarioSalario = et_usuario_salario.getText().toString();
    }

    public boolean montaObjetoTela() {
        recuperaInformacoesTela();
        boolean retorno = true;
        if (!FormularioUtil.verificaCampos((Arrays.asList(usuarioNome, usuarioEmail, usuarioSalario)))) {
            retorno = false;
        } else{
            usuarioFormulario.setNome(usuarioNome);
            usuarioFormulario.setEmail(usuarioEmail);
            usuarioFormulario.setCarteira(new Carteira(Double.parseDouble(usuarioSalario)));
        }
        return retorno;
    }

    public void salvarInformacoesTela(){
        bt_usuario_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(montaObjetoTela()){
                    usuarioDAO.salvar(usuarioFormulario);
                }else{
                    Toast.makeText(usuarioActivity, "Todos os campos são obrigatórios", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
