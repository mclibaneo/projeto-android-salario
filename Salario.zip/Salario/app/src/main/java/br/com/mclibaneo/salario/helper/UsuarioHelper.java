package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Arrays;

import br.com.mclibaneo.salario.MainActivity;
import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.contract.CategoriaContract;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.dao.UsuarioCateiraDAO;
import br.com.mclibaneo.salario.model.Categoria;
import br.com.mclibaneo.salario.model.UsuarioCarteira;
import br.com.mclibaneo.salario.util.FormularioUtil;

public class UsuarioHelper extends Activity{

    private Activity usuarioActivity;

    private EditText et_usuario_nome;
    private EditText et_usuario_email;
    private EditText et_usuario_salario;
    private EditText et_usuario_poupanca;
    private EditText et_usuario_id;

    private String usuarioID;
    private String usuarioNome;
    private String usuarioEmail;
    private String usuarioSalario;
    private String usuarioPoupanca;

    private boolean usuarioNovo;

    private Button bt_usuario_salvar;

    private UsuarioCarteira usuarioCarteiraFormulario;
    private UsuarioCateiraDAO usuarioCateiraDAO;

    private AlertDialog.Builder builder;

    /*
    * construtor
    * define um construtor contextualizado
    * */
    public UsuarioHelper(Activity activity){
        //informa o contexto
        this.usuarioActivity = activity;
        //inicia o dao a partir do contexto
        this.usuarioCateiraDAO = new UsuarioCateiraDAO(activity);
        //recupera as views da tela
        recuperaInformacoesTela();
        //adiciona acoes dos listeners
        setListeners();
        //cria uma dialog
        configDialog();

    }
    /*
    * param: nenhum, retorno: void
    * configura uma Dialog
    * */
    private void configDialog(){
        this.builder = new AlertDialog.Builder(usuarioActivity);
        builder.setMessage(R.string.dialog_mensagem);
    }
    /*
    * param: nenhum, retorno: void
    * recupera as informacoes das views da tela
    * insere os valores em uma string
    * */
    public void recuperaInformacoesTela(){
        this.et_usuario_id = (EditText) usuarioActivity.findViewById(R.id.et_usuario_id);
        this.et_usuario_email = (EditText) usuarioActivity.findViewById(R.id.et_usuario_email);
        this.et_usuario_nome = (EditText) usuarioActivity.findViewById(R.id.et_usuario_nome);
        this.et_usuario_salario = (EditText) usuarioActivity.findViewById(R.id.et_usuario_salario_bruto);
        this.et_usuario_poupanca = (EditText) usuarioActivity.findViewById(R.id.et_usuario_poupanca);

        this.bt_usuario_salvar = (Button) usuarioActivity.findViewById(R.id.bt_usuario_salvar);

        //insere valores em string para uso posterior
        this.usuarioID = et_usuario_id.getText().toString().trim();
        this.usuarioNome = et_usuario_nome.getText().toString().trim();
        this.usuarioEmail = et_usuario_email.getText().toString().trim();
        this.usuarioSalario = et_usuario_salario.getText().toString().trim();
        this.usuarioPoupanca = et_usuario_poupanca.getText().toString().trim();

        this.usuarioNovo = usuarioActivity.getIntent().getBooleanExtra(usuarioActivity.getString(R.string.usuarioNovo), false);

    }
    /*
    * param: nenhum, retorno: boolean
    * recupera os valores da tela e verifica se sao nulos ou vazios
    * retorna true caso estejam preenchidos
    * */
    public boolean montaUsuario() {
        recuperaInformacoesTela();
        boolean retorno = true;
        if (!FormularioUtil.verificaCampos((Arrays.asList(usuarioNome, usuarioEmail, usuarioSalario)))) {
            retorno = false;
        } else{
            usuarioCarteiraFormulario = new UsuarioCarteira();
            usuarioCarteiraFormulario.setNomeUsuario(usuarioNome);
            usuarioCarteiraFormulario.setEmailUsuario(usuarioEmail);
            usuarioCarteiraFormulario.setSalarioBruto(Double.parseDouble(usuarioSalario));
            if(!(FormularioUtil.verificaCampo(usuarioPoupanca))){
                usuarioCarteiraFormulario.setPoupanca(0);
            }else{
                usuarioCarteiraFormulario.setPoupanca(Double.parseDouble(usuarioPoupanca));
            }
            if(FormularioUtil.verificaCampo(usuarioID))
                usuarioCarteiraFormulario.setIdUsuarioCarteira(Long.parseLong(usuarioID));


        }
        return retorno;
    }
    /*
    * param: nenhum, retorno: void
    * insere informacoes na tela caso exista um usuario
    * */
    public void insereUsuarioTela(){
        if(usuarioCateiraDAO.usuarioExiste()){
            usuarioCarteiraFormulario = usuarioCateiraDAO.listar();
            this.et_usuario_id.setText(String.valueOf(usuarioCarteiraFormulario.getIdUsuarioCarteira()));
            this.et_usuario_nome.setText(usuarioCarteiraFormulario.getNomeUsuario());
            this.et_usuario_email.setText(usuarioCarteiraFormulario.getEmailUsuario());
            this.et_usuario_salario.setText(String.valueOf(usuarioCarteiraFormulario.getSalarioBruto()));
            this.et_usuario_poupanca.setText(String.valueOf(usuarioCarteiraFormulario.getPoupanca()));
            //deixa os campos nao editaveis
            this.et_usuario_nome.setEnabled(false);
            this.et_usuario_email.setEnabled(false);
        }

    }
    /*
    * param: nenhum, retorno: void
    * insere listeners aos elementos da tela
    * */
    public void setListeners(){
        bt_usuario_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarInformacoesTela();
            }
        });
    }
    /*
    * param: nenhum, retorno: void
    * verifica se usuario ja possui categorias se nao possuir cria as categorias padroes
    * */
    private void insereCategoriasPadroes(){
        CategoriaDAO categoriaDAO = new CategoriaDAO(usuarioActivity);
        //insere categorias padroes se nao houver dados no banco de dados (esta funcionalidade sera removida daqui)
        if (!(categoriaDAO.listar().size() > 0)) {
            for (String s : CategoriaContract.cCategoria.VALUES_CATEGORIAS_PADROES) {
                categoriaDAO.salvar(new Categoria(s));
            }
        }
    }
    /*
    * param: nenhum, retorno: void
    * monta o objeto para ser salvo e realiza a persistencia no banco de dados
    * informa usuario caso ocorra um erro
    * */
    private void salvarInformacoesTela(){
        if(montaUsuario()){
            //salva a carteira
            builder.setPositiveButton(R.string.dialog_confirma, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                        insereCategoriasPadroes();
                        if (usuarioCateiraDAO.salvar(usuarioCarteiraFormulario) > 0) {
                            usuarioCateiraDAO.close();
                            Toast.makeText(usuarioActivity, usuarioActivity.getString(R.string.operacao_sucesso), Toast.LENGTH_LONG).show();
                            //Verifica se eh novoUsuario
                            if(usuarioNovo){
                                //volta para a mainActivity
                                usuarioActivity.finish();
                                usuarioActivity.startActivity(new Intent(usuarioActivity, MainActivity.class));
                            }


                        } else {
                            Toast.makeText(usuarioActivity, usuarioActivity.getString(R.string.operacao_falha), Toast.LENGTH_LONG).show();
                        }
                    }
                }

                ).

                setNegativeButton(R.string.dialog_cancela, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //nao faz nada
                            }
                        }

                );
                builder.create().

                show();
            }else
            Toast.makeText(usuarioActivity, usuarioActivity.getString(R.string.todos_campos_obrigatorios), Toast.LENGTH_LONG).show();

    }
}
