package br.com.mclibaneo.salario.util;

import java.util.List;

/**
 * Created by 121101 on 19/04/2016.
 */
public class FormularioUtil {

    public static boolean verificaCampos(List<String> campos){
        boolean retorno = true;
        for(String campo : campos){
            if(campo.isEmpty() || campo == null)
                retorno = false;
        }
        return retorno;
    }
}
