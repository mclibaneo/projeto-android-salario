package br.com.mclibaneo.salario.util;

import android.widget.Adapter;
import android.widget.Spinner;

import java.util.List;

/**
 * Created by 121101 on 19/04/2016.
 */
public abstract class FormularioUtil {

    public static boolean verificaCampos(List<String> campos){
        boolean retorno = true;
        for(String campo : campos){
            if(campo.isEmpty() || campo == null)
                retorno = false;
        }
        return retorno;
    }

    public static void recuperaValorSpinner(Spinner sp, String valor ){
        Adapter adapterSpinner = sp.getAdapter();
        for(int i=0; i<adapterSpinner.getCount(); i++){
            if(valor.equals(adapterSpinner.getItem(i)))
                sp.setSelection(i);
        }
    }
}
