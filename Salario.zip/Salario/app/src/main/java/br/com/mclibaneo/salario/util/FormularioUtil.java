package br.com.mclibaneo.salario.util;

import android.app.Activity;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

import br.com.mclibaneo.salario.CategoriasActivity;
import br.com.mclibaneo.salario.R;

/**
 * Created by 121101 on 19/04/2016.
 */
public abstract class FormularioUtil {
    /*
    * param: List<String>, retorno: boolean
    * recebe uma lista de campos strings e verifica se estão preenchidos,
    * retorna falso caso estejam nulos ou vazios
    * */
    public static boolean verificaCampos(List<String> campos){
        boolean retorno = true;
        for(String campo : campos){
            if(campo.isEmpty() || campo == null)
                retorno = false;
        }
        return retorno;
    }
    /*
    * param: Spinner e String, retorno: void
    * recebe um objeto spinner e uma string com a categoria,
    * insere dentro do spinner o valor da categoria enviada
    * */
    public static void recuperaValorSpinner(Spinner sp, String valor ){
        Adapter adapterSpinner = sp.getAdapter();
        for(int i=0; i<adapterSpinner.getCount(); i++){
            if(valor.equals(adapterSpinner.getItem(i)))
                sp.setSelection(i);
        }
    }
    /*
    * param: ArrayList<String>, retorno: Spinner
    * recebe uma lista com string das categorias,
    * retorna um objeto spinner populado
    * */
    public static void retornaSpinnerPopulado(Spinner spinner, Activity activity, ArrayList<String> values){
        if(!(values.size()>0)) {
            values = new ArrayList<>();
            values.add("Não há Dados");
        }
        ArrayAdapter<String> adapterSpinner = new ArrayAdapter<String>(activity,
                android.R.layout.simple_spinner_item, values);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapterSpinner);
    }
}
