package br.com.mclibaneo.salario.util;

import android.app.Activity;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import br.com.mclibaneo.salario.CategoriasActivity;
import br.com.mclibaneo.salario.R;

public abstract class FormularioUtil {
    /*
    * param: List<String>, retorno: boolean
    * recebe uma lista de campos strings e verifica se estão preenchidos,
    * retorna falso caso estejam nulos ou vazios
    * */
    public static boolean verificaCampos(List<String> campos){
        boolean retorno = true;
        for(String campo : campos){
            if(campo.isEmpty() || campo == null)
                retorno = false;
        }
        return retorno;
    }
    /*
    * param: String, retorno: boolean
    * recebe um valor string e verifica se eh nulo ou vazio
    * retorna verdadeiro caso esteja preenchido
    * */
    public static boolean verificaCampo(String campo){
        boolean retorno = true;
        if(campo.isEmpty() || campo == null)
            retorno = false;
        return retorno;
    }
    /*
    * param: Spinner e String, retorno: void
    * recebe um objeto spinner e uma string com a categoria,
    * insere dentro do spinner o valor da categoria enviada
    * */
    public static void recuperaValorSpinner(Spinner sp, String valor ){
        Adapter adapterSpinner = sp.getAdapter();
        for(int i=0; i<adapterSpinner.getCount(); i++){
            if(valor.equals(adapterSpinner.getItem(i).toString()))
                sp.setSelection(i);
        }
    }
    /*
    * param: ArrayList<String>, retorno: Spinner
    * recebe uma lista com string das categorias,
    * retorna um objeto spinner populado
    * */
    public static void retornaSpinnerPopulado(Spinner spinner, Activity activity, ArrayList<String> values){
        if(!(values.size()>0)) {
            values = new ArrayList<>();
            values.add("Não há Dados");
        }
        ArrayAdapter<String> adapterSpinner = new ArrayAdapter<String>(activity,
                android.R.layout.simple_spinner_item, values);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapterSpinner);
    }
    /*
    * param: Spinner, Activity; retorno: void
    * cria um spinner com os dias do mes
    * */
    public static void criaSpinnerDias(Spinner spinner, Activity activity){
        Integer[] dias = new Integer[31];
        for(int i=0; i<=30; i++){
            dias[i] = i+1;
        }
        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(
                activity,
                android.R.layout.simple_spinner_item,
                dias);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
    /*
   * param: Spinner, Activity; retorno: void
   * cria um spinner com os meses do ano
   * */
    public static void criaSpinnerMeses(Spinner spinner, Activity activity){
        ArrayAdapter adapter = ArrayAdapter.createFromResource(
                activity,
                R.array.array_meses,
                android.R.layout.simple_spinner_item
                );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }
    /*
    * param: ListView, ArrayList<Object>; retorno: void
    * recebe uma lista com objetos
    * e retorna a listview populada
    * */
    public static void retornaListViewPopulado(ListView lv, Activity activity, ArrayList values){
        ArrayAdapter adapter = new ArrayAdapter(
                activity,
                android.R.layout.simple_list_item_1,
                values
        );
        lv.setAdapter(adapter);
    }
    /*
    * param: double -> valor; retorno: String -> com valor formatado
    * recebe um valor em double e retorna uma string formatada em monetario
    * */
    public static String formataValorDouble(double valor){
        DecimalFormat decimalFormat = new DecimalFormat("##,###,###,##0.00", new DecimalFormatSymbols(DataUtil.getLocaleBrasil()));
        decimalFormat.setMinimumFractionDigits(2);
        decimalFormat.setParseBigDecimal(true);
        return String.valueOf(decimalFormat.format(valor));
    }
}
