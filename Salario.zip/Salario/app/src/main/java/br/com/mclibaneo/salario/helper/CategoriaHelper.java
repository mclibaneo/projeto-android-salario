package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.Arrays;

import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.model.Categoria;
import br.com.mclibaneo.salario.util.FormularioUtil;

/**
 * Created by 121101 on 19/04/2016.
 */
public class CategoriaHelper extends Activity {
    private Activity categoriaActivity;
    private EditText et_categoria_nome;
    private Spinner sp_categoria;
    private Button bt_categoria_salvar;

    private String nomeCategoria;

    private Categoria categoriaFormulario;
    private CategoriaDAO categoriaDAO;

    public CategoriaHelper(Activity activity){
        this.categoriaActivity = activity;

        categoriaFormulario = new Categoria();
        categoriaDAO = new CategoriaDAO(activity);

        recuperaInformacoesTela();
        setListeners();
        insereInformacoesTela();

    }

    public void recuperaInformacoesTela(){
        this.et_categoria_nome = (EditText) categoriaActivity.findViewById(R.id.et_categoria_nome);
        this.sp_categoria = (Spinner) categoriaActivity.findViewById(R.id.sp_categoria);
        this.bt_categoria_salvar = (Button) categoriaActivity.findViewById(R.id.bt_categoria_salvar);

        this.nomeCategoria = et_categoria_nome.getText().toString();
    }

    public void recuperaInformacoesObjeto(Categoria categoria){
        et_categoria_nome.setText(categoria.getNomeCategoria());
        FormularioUtil.recuperaValorSpinner(sp_categoria, categoria.getCategoriaPai());
    }

    public boolean montaObjetoTela(){
        recuperaInformacoesTela();
        boolean retorno = true;
            if(FormularioUtil.verificaCampos(Arrays.asList(nomeCategoria))){
                categoriaFormulario.setNomeCategoria(nomeCategoria);
            }else{
                retorno = false;
            }
        return retorno;
    }

    public void insereInformacoesTela(){
        ArrayAdapter<CharSequence> adapterSpinner = ArrayAdapter.createFromResource(categoriaActivity,
                R.array.cateorias_pai, android.support.design.R.layout.support_simple_spinner_dropdown_item);
        sp_categoria.setAdapter(adapterSpinner);
    }



    public void setListeners(){
        sp_categoria.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String categoriaPai = parent.getItemAtPosition(position).toString();
                if(categoriaPai == "Sem Categoria Pai")
                    categoriaFormulario.setCategoriaPai(null);
                else
                    categoriaFormulario.setCategoriaPai(categoriaPai);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        bt_categoria_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (montaObjetoTela()) {
                    if(categoriaDAO.salvar(categoriaFormulario) > 0){
                        Toast.makeText(categoriaActivity,"Categoria Salva!",Toast.LENGTH_SHORT).show();
                        categoriaDAO.close();
                        finish();
                    }else
                        Toast.makeText(categoriaActivity,"Não foi possível salvar categoria.",Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(categoriaActivity, "Necessário informar todos os campos.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
