package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.com.mclibaneo.salario.CategoriasActivity;
import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.model.Categoria;
import br.com.mclibaneo.salario.util.FormularioUtil;

/**
 * Created by 121101 on 19/04/2016.
 */
public class CategoriaHelper extends Activity {
    private Activity categoriaActivity;
    private EditText et_categoria_id;
    private EditText et_categoria_nome;
    private Spinner sp_categoria;
    private Button bt_categoria_salvar;

    private String idCategoria;
    private String nomeCategoria;

    private Categoria categoriaFormulario;
    private CategoriaDAO categoriaDAO;

    public CategoriaHelper(Activity activity){
        this.categoriaActivity = activity;
        categoriaFormulario = new Categoria();
        categoriaDAO = new CategoriaDAO(activity);
        recuperaInformacoesTela();
        setListeners();
        insereInformacoesTela();
        verificaExtra();
    }
    /*
    * Param: nenhum, Retorno: void
    * Recupera as informacoes de todas as views da Activiy
    * */
    public void recuperaInformacoesTela(){
        this.et_categoria_id = (EditText) categoriaActivity.findViewById(R.id.et_categoria_id);
        this.et_categoria_nome = (EditText) categoriaActivity.findViewById(R.id.et_categoria_nome);
        this.sp_categoria = (Spinner) categoriaActivity.findViewById(R.id.sp_categoria);
        this.bt_categoria_salvar = (Button) categoriaActivity.findViewById(R.id.bt_categoria_salvar);

        this.idCategoria = et_categoria_id.getText().toString();
        this.nomeCategoria = et_categoria_nome.getText().toString();
    }
    /*
    * Param: Objeto categoria, Retorno: void
    * Insere um objeto na Activity para ser editado
    * */
    public void recuperaInformacoesObjeto(Categoria categoria){
        et_categoria_id.setText(categoria.getIdCategoria().toString());
        et_categoria_nome.setText(categoria.getNomeCategoria());
        FormularioUtil.recuperaValorSpinner(sp_categoria, categoria.getNomeCategoria());
    }
    /*
    * param: nenhum, retorno: void
    * Insere as informacoes do ID do objeto caso este for editavel
    * */
    public void montaObjetoParaEdicao(){
        if(!idCategoria.isEmpty())
            categoriaFormulario.setIdCategoria(Long.parseLong(idCategoria));
        categoriaFormulario.setCategoriaPai(null); // sera modificado posteriormente
    }
    /*
    * Param: nenhum, Retorno: boolean
    * Recupera informacoes da Activity e monta um objeto do tipo categoria
    * para ser salvo na base de dados
    * */
    public boolean montaObjetoTela(){
        boolean retorno = true;
        recuperaInformacoesTela();
        montaObjetoParaEdicao();
        if(FormularioUtil.verificaCampos(Arrays.asList(nomeCategoria))){
            categoriaFormulario.setNomeCategoria(nomeCategoria);
        }else{
            retorno = false;
        }
        return retorno;
    }
    /*
    * param: nenhum, retorno: void
    * Monta um objeto spinner com arrays de categorias e envia para ser mostrado na Activity
    * */
    public void insereInformacoesTela(){
        ArrayList<String> values = categoriaDAO.listarString();
        FormularioUtil.retornaSpinnerPopulado(sp_categoria, categoriaActivity, values);
    }
    /*
    * param: nenhum, retorno: void
    * verifica se existe um extras da intent,
    * se existir convert o extra em uma categoria e monta o objeto na tela
    * */
    public void verificaExtra(){
        Categoria categoriaIntent;
        categoriaIntent = (Categoria) categoriaActivity.getIntent().getSerializableExtra("categoria");
        if(categoriaIntent != null){
            recuperaInformacoesObjeto(categoriaIntent);
        }else{
            insereInformacoesTela();
        }
    }

    /*
    * param: nenhum, retorno: void
    * Inicia todos os listener dos objetos da activity
    * */
    public void setListeners(){
        //listener para objeto spinner -- metodo inutilizado!!!
        sp_categoria.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //obtem a string do objeto selecionado no spinner
                String categoriaPai = parent.getItemAtPosition(position).toString();
                categoriaFormulario.setCategoriaPai(categoriaPai);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                categoriaFormulario.setCategoriaPai(null);
            }
        });
        //listener para o botao SALVAR
        bt_categoria_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvaInformacoesTela();
            }
        });
    }
    /*
    * param: nenhum, retorno: void
    * salva as informacoes da tela no banco de dados
    * informa usuario caso nao seja possivel realizar a operacao
    * */
    public void salvaInformacoesTela(){
        if (montaObjetoTela()) {
            if(categoriaDAO.salvar(categoriaFormulario) > 0){
                Toast.makeText(categoriaActivity,categoriaActivity.getString(R.string.operacao_sucesso),Toast.LENGTH_SHORT).show();
                categoriaDAO.close();
                categoriaActivity.finish();
                categoriaActivity.startActivity(new Intent(categoriaActivity, CategoriasActivity.class));
            }else
                Toast.makeText(categoriaActivity,categoriaActivity.getString(R.string.operacao_falha),Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(categoriaActivity, categoriaActivity.getString(R.string.todos_campos_obrigatorios), Toast.LENGTH_LONG).show();
        }
    }
}
