package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import br.com.mclibaneo.salario.CategoriaActivity;
import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.model.Categoria;


public class CategoriasHelper extends Activity {

    private ListView listView;
    private Activity categoriasActivity;
    private CategoriaDAO categoriasDAO;
    private Categoria categoriaHelper;
    private ActionMode mActionMode;
    private Intent intent;

    public CategoriasHelper(Activity activity){
        this.categoriasDAO = new CategoriaDAO(activity);
        this.categoriasActivity = activity;
        recuperaInformacoesTela();
        insereInformacoesTela();
        setListeners();
    }
    /*
    * param: nenhum, retorno: void
    * Recupera a List View de categorias da activity
    * */
    private void recuperaInformacoesTela(){
        this.listView = (ListView) categoriasActivity.findViewById(R.id.lv_categorias);
    }
    /*
    * param: nenhum, retorno: void
    * Insere uma List View de categorias na activity
    * */
    public void insereInformacoesTela(){
        ArrayList<Categoria> lista = categoriasDAO.lista();
        ArrayAdapter<Categoria> adapter = new ArrayAdapter<Categoria>(categoriasActivity, android.R.layout.simple_list_item_1, lista);
        listView.setAdapter(adapter);
    }
     /*
    * param: nenhum, retorno: void
    * Adiciona Listeners nos elementos da activity
    * */
    private void setListeners(){
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                categoriaHelper = (Categoria) parent.getItemAtPosition(position);
                Log.i("ITEM_LISTA", "Categoria: " + categoriaHelper);
                if(mActionMode != null){
                    return false;
                }
                mActionMode = categoriasActivity.startActionMode(mActionModeCallback);
                view.setSelected(true);
                return true;
            }
        });
    }
    /*
    * param: nenhum, retorno: ActionMode
    * Inicia um ActionMode para criar um menu de contexto na action bar
    * */
    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback(){

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.menu_context_categorias, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()){
                case R.id.menu_context_categorias_editar:
                    //editar categoria selecionada
                    intent = new Intent(categoriasActivity, CategoriaActivity.class);
                    intent.putExtra("categoria", categoriaHelper);
                    categoriasActivity.startActivity(intent);
                    mode.finish();
                    return true;
                case R.id.menu_context_categorias_apagar:
                    //apagar categoria selecionada
                    categoriasDAO.remover(categoriaHelper);
                    insereInformacoesTela();
                    mode.finish();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;
        }
    };
}
