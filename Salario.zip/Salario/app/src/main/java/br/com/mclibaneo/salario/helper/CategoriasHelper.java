package br.com.mclibaneo.salario.helper;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import br.com.mclibaneo.salario.CategoriaActivity;
import br.com.mclibaneo.salario.R;
import br.com.mclibaneo.salario.contract.CategoriaContract;
import br.com.mclibaneo.salario.dao.CategoriaDAO;
import br.com.mclibaneo.salario.model.Categoria;


public class CategoriasHelper extends Activity {

    private TextView tv_categorias;
    private ListView listView;
    private Activity categoriasActivity;
    private CategoriaDAO categoriasDAO;
    private Categoria categoria;
    private ActionMode mActionMode;
    private Intent intent;

    public CategoriasHelper(Activity activity){
        this.categoriasDAO = new CategoriaDAO(activity);
        this.categoriasActivity = activity;
        recuperaInformacoesTela();
        setListeners();
        insereInformacoesTela();
    }
    /*
    * param: nenhum, retorno: void
    * Recupera a List View de categorias da activity
    * */
    private void recuperaInformacoesTela(){
        this.listView = (ListView) categoriasActivity.findViewById(R.id.lv_categorias);
        this.tv_categorias = (TextView) categoriasActivity.findViewById(R.id.tv_categorias);
    }
    /*
    * param: nenhum, retorno: void
    * cria uma string com todas as categorias alinhadas as suas respectivas categorias pai
    * */
    public String criaListaItensSubitens(){
        //busca as categorias pais e insere em um array list
        ArrayList<String> categoriasPai = categoriasDAO.listarCategoriasPais();
        //busca todas as categorias e insere em um array list
        ArrayList<Categoria> categorias = categoriasDAO.listar();
        //adiciona uma categoria pai e vai adicionando ao array list as categorias pertecentes a ela
        ArrayList<ArrayList<String>> listaCategorias = new ArrayList<ArrayList<String>>();
        String listaCategoriaString = "";
        for(String s : categoriasPai){
            int i = 1;
            ArrayList<String> datum = new ArrayList<String>();
            datum.add(s);
            for(Categoria c : categorias){
                if(s.equals(c.getCategoriaPai())){
                    datum.add(c.getNomeCategoria());
                }
            }
            listaCategorias.add(datum);
        }

        for(ArrayList<String> array : listaCategorias){
            String pai = "";
            String categoria = "";
            pai = array.get(0).toString().concat("\n");
            for(int i = 1; i<array.size(); i++){
                    categoria += array.get(i).toString().concat("\n");
            }
            listaCategoriaString += pai.concat(categoria);
        }
        Log.i("String Lista: ", listaCategoriaString);

        return listaCategoriaString;

        /*List<Map<String,String>> data = new ArrayList<Map<String, String>>();
        for(Categoria c : lista){
            Map<String,String> datum = new HashMap<String, String>(2);
            datum.put("item", c.getCategoriaPai());
            datum.put("subitem", c.getNomeCategoria());
            data.add(datum);
        }
        SimpleAdapter adapter = new SimpleAdapter(categoriasActivity,
                data,
                android.R.layout.simple_list_item_2,
                new String[] {"item", "subitem"},
                new int[] {android.R.id.text1, android.R.id.text2});*/
    }
    /*
    * param: nenhum, retorno: void    *
    * cria um cursor com informacoes do banco e joga em um SimpleCursorAdapter para mostrar na tela
    * */
    public void insereCursorInformacoesTela(){
         ArrayList<String> listaPais = categoriasDAO.listarCategoriasPais();

        Cursor cursor = categoriasDAO.cursorListaCategorias();
        String[] coluns = new String[]{CategoriaContract.cCategoria.COLUMN_NAME_PAI, CategoriaContract.cCategoria.COLUMN_NAME_CATEGORIA};

        SimpleCursorAdapter scAdapter = new SimpleCursorAdapter(
                categoriasActivity, //contexto para mostrar a lista --> activity context
                R.layout.lista_categorias, // modelo da lista a ser adptada --> int
                cursor, // o objeto cursor com os dados a serem mostrados --> cursor
                coluns, // as colunas a serem mostradas --> string[]
                new int[] {R.id.tv_lista_categorias_item, R.id.tv_lista_categorias_subitens}, //especifica o estilo do texto de cada coluna --> int[]
                0 // flag --> int
        );

        listView.setAdapter(scAdapter);


       /* ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                categoriasActivity,
                android.R.layout.simple_list_item_1,
                categoriasDAO.listarCategoriasPais());*/

        /*List<Map<String,String>> data = new ArrayList<Map<String, String>>();
        for(Categoria c : lista){
            Map<String,String> datum = new HashMap<String, String>(2);
            datum.put("item", c.getCategoriaPai());
            datum.put("subitem", c.getNomeCategoria());
            data.add(datum);
        }
        SimpleAdapter adapter = new SimpleAdapter(categoriasActivity,
                data,
                android.R.layout.simple_list_item_2,
                new String[] {"item", "subitem"},
                new int[] {android.R.id.text1, android.R.id.text2});*/
    }
    /*
    * param: nenhum, retorno: void
    * Insere uma List View de categorias na activity
    * */
    public void insereInformacoesTela(){
        //insere categorias padroes se nao houver dados no banco de dados (esta funcionalidade sera removida daqui)
        if(!(categoriasDAO.listar().size()>0)){
        for(String s : CategoriaContract.cCategoria.VALUES_CATEGORIAS_PADROES) {
            categoriasDAO.salvar(new Categoria(s));
        }
        //se houver itens carrega a lista do banco de dados
        }else{
            //cria um spinner a partir do banco de dados
            ArrayList<Categoria> lista = categoriasDAO.listar();
            ArrayAdapter<Categoria> adapter = new ArrayAdapter<Categoria>(
                    categoriasActivity,
                    android.R.layout.simple_list_item_1,
                    lista);
            listView.setAdapter(adapter);
        }

    }
    /*
    * param: nenhum, retorno: void
    * Adiciona Listeners nos elementos da activity
    * */
    private void setListeners(){
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(categoriasActivity, "Item:"+parent.getItemAtPosition(position), Toast.LENGTH_LONG).show();
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                categoria = (Categoria) parent.getItemAtPosition(position);
                Log.i("ITEM_LISTA", "Categoria: " + categoria);
                if(mActionMode != null){
                    return false;
                }
                mActionMode = categoriasActivity.startActionMode(mActionModeCallback);
                view.setSelected(true);
                return true;
            }
        });
    }
    /*
    * param: nenhum, retorno: ActionMode
    * Inicia um ActionMode para criar um menu de contexto na action bar
    * */
    private ActionMode.Callback mActionModeCallback = new ActionMode.Callback(){

        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.menu_context_categorias, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            switch (item.getItemId()){
                case R.id.menu_context_categorias_editar:
                    //editar categoria selecionada
                    intent = new Intent(categoriasActivity, CategoriaActivity.class);
                    intent.putExtra("categoria", categoria);
                    categoriasActivity.startActivity(intent);
                    mode.finish();
                    return true;
                case R.id.menu_context_categorias_apagar:
                    //apagar categoria selecionada
                    categoriasDAO.remover(categoria);
                    insereInformacoesTela();
                    mode.finish();
                    return true;
                default:
                    return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            mActionMode = null;
        }
    };
}
