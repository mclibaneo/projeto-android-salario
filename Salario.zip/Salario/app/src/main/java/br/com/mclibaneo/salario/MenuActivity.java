package br.com.mclibaneo.salario;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

/**
 * Created by 121101 on 18/04/2016.
 */
public class MenuActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_main_config) {
            startActivity(new Intent(this, UsuarioActivity.class));
            return true;
        }

        if(id == R.id.menu_main_despesa){
            startActivity(new Intent(this, MovimentacaoActivity.class).putExtra("despesa", true));
            return true;
        }

        if(id == R.id.menu_main_receita){
            startActivity(new Intent(this, MovimentacaoActivity.class).putExtra("despesa", false));
            return true;
        }

        if(id == R.id.menu_main_categoria){
            startActivity(new Intent(this, CategoriaActivity.class));
            return true;
        }

        if(id == R.id.menu_main_categorias){
            startActivity(new Intent(this, CategoriasActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
