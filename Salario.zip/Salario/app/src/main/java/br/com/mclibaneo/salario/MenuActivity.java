package br.com.mclibaneo.salario;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

public class MenuActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_main_carteira) {
            startActivity(new Intent(this, UsuarioActivity.class));
            return true;
        }

        if(id == R.id.menu_main_despesa){
            startActivity(new Intent(this, MovimentacaoActivity.class).putExtra(this.getString(R.string.intencaoDespesa), true));
            return true;
        }

        if(id == R.id.menu_main_receita){
            startActivity(new Intent(this, MovimentacaoActivity.class).putExtra(this.getString(R.string.intencaoDespesa), false));
            return true;
        }

        if(id == R.id.menu_main_salario){
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }

        if(id == R.id.menu_main_categorias){
            startActivity(new Intent(this, CategoriasActivity.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
